﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace TouchPadSensorData
{
    class TouchPadSensorData
    {
        static void Main(string[] args)
        {
            string dir = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            
            //this is path C:\Users\uidq4218\Documents\Visual Studio 2015\Projects\TouchPadSensorData\TouchPadSensorData\bin\Debug.
            string file = dir + @"\Sample_Sensordata_Input.txt";
            StreamReader sr = new StreamReader(file);

            Thread.Sleep(5000);
            sr.Close();
        }
    }
}
