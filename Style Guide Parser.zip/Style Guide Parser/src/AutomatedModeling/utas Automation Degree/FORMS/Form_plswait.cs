﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace New_Modeling.FORMS
{
    public partial class Form_plswait : Form
    {
        public Form_plswait()
        {
            InitializeComponent();
        }
        public void close_PopUp(object sender, EventArgs ag)
        {
            this.Close();
        }
    }
}
