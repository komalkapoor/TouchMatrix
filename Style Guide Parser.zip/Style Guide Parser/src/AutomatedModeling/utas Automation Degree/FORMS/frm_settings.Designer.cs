﻿namespace Automatic_Modeling.FORMS
{
    partial class frm_settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlp_settings = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_ignored_macros = new System.Windows.Forms.TextBox();
            this.tlp_multiplier = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.num_multiplier = new System.Windows.Forms.NumericUpDown();
            this.testCtrlSkipChkBox = new System.Windows.Forms.CheckBox();
            this.paramSheetSkipChkBox = new System.Windows.Forms.CheckBox();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.testStepSkipChkBox = new System.Windows.Forms.CheckBox();
            this.chk_withParams = new System.Windows.Forms.CheckBox();
            this.tlp_settings.SuspendLayout();
            this.tlp_multiplier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_multiplier)).BeginInit();
            this.SuspendLayout();
            // 
            // tlp_settings
            // 
            this.tlp_settings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlp_settings.ColumnCount = 2;
            this.tlp_settings.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlp_settings.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlp_settings.Controls.Add(this.label1, 0, 0);
            this.tlp_settings.Controls.Add(this.txt_ignored_macros, 0, 1);
            this.tlp_settings.Controls.Add(this.tlp_multiplier, 0, 2);
            this.tlp_settings.Controls.Add(this.testCtrlSkipChkBox, 0, 3);
            this.tlp_settings.Controls.Add(this.paramSheetSkipChkBox, 0, 4);
            this.tlp_settings.Controls.Add(this.btn_OK, 0, 7);
            this.tlp_settings.Controls.Add(this.btn_cancel, 1, 7);
            this.tlp_settings.Controls.Add(this.testStepSkipChkBox, 0, 5);
            this.tlp_settings.Controls.Add(this.chk_withParams, 0, 6);
            this.tlp_settings.Location = new System.Drawing.Point(12, 12);
            this.tlp_settings.Name = "tlp_settings";
            this.tlp_settings.RowCount = 8;
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tlp_settings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tlp_settings.Size = new System.Drawing.Size(302, 275);
            this.tlp_settings.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.tlp_settings.SetColumnSpan(this.label1, 2);
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ignored Macros (excluded from calculation)";
            // 
            // txt_ignored_macros
            // 
            this.txt_ignored_macros.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ignored_macros.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tlp_settings.SetColumnSpan(this.txt_ignored_macros, 2);
            this.txt_ignored_macros.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ignored_macros.Location = new System.Drawing.Point(3, 23);
            this.txt_ignored_macros.Multiline = true;
            this.txt_ignored_macros.Name = "txt_ignored_macros";
            this.txt_ignored_macros.Size = new System.Drawing.Size(296, 84);
            this.txt_ignored_macros.TabIndex = 1;
            // 
            // tlp_multiplier
            // 
            this.tlp_multiplier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlp_multiplier.ColumnCount = 3;
            this.tlp_settings.SetColumnSpan(this.tlp_multiplier, 2);
            this.tlp_multiplier.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tlp_multiplier.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlp_multiplier.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlp_multiplier.Controls.Add(this.label2, 0, 0);
            this.tlp_multiplier.Controls.Add(this.label3, 2, 0);
            this.tlp_multiplier.Controls.Add(this.num_multiplier, 1, 0);
            this.tlp_multiplier.Location = new System.Drawing.Point(3, 113);
            this.tlp_multiplier.Name = "tlp_multiplier";
            this.tlp_multiplier.RowCount = 1;
            this.tlp_multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlp_multiplier.Size = new System.Drawing.Size(296, 29);
            this.tlp_multiplier.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Default Multiplier";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(259, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "%";
            // 
            // num_multiplier
            // 
            this.num_multiplier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.num_multiplier.DecimalPlaces = 2;
            this.num_multiplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_multiplier.Location = new System.Drawing.Point(153, 3);
            this.num_multiplier.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_multiplier.Name = "num_multiplier";
            this.num_multiplier.Size = new System.Drawing.Size(100, 23);
            this.num_multiplier.TabIndex = 1;
            this.num_multiplier.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // testCtrlSkipChkBox
            // 
            this.testCtrlSkipChkBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.testCtrlSkipChkBox.AutoSize = true;
            this.testCtrlSkipChkBox.Checked = true;
            this.testCtrlSkipChkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tlp_settings.SetColumnSpan(this.testCtrlSkipChkBox, 2);
            this.testCtrlSkipChkBox.Location = new System.Drawing.Point(3, 148);
            this.testCtrlSkipChkBox.Name = "testCtrlSkipChkBox";
            this.testCtrlSkipChkBox.Size = new System.Drawing.Size(296, 19);
            this.testCtrlSkipChkBox.TabIndex = 4;
            this.testCtrlSkipChkBox.Text = "Consider Test Control Enable/Skip flag";
            this.testCtrlSkipChkBox.UseVisualStyleBackColor = true;
            // 
            // paramSheetSkipChkBox
            // 
            this.paramSheetSkipChkBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.paramSheetSkipChkBox.AutoSize = true;
            this.paramSheetSkipChkBox.Checked = true;
            this.paramSheetSkipChkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tlp_settings.SetColumnSpan(this.paramSheetSkipChkBox, 2);
            this.paramSheetSkipChkBox.Location = new System.Drawing.Point(3, 173);
            this.paramSheetSkipChkBox.Name = "paramSheetSkipChkBox";
            this.paramSheetSkipChkBox.Size = new System.Drawing.Size(296, 19);
            this.paramSheetSkipChkBox.TabIndex = 5;
            this.paramSheetSkipChkBox.Text = "Consider Param Sheet Run/Skip flag";
            this.paramSheetSkipChkBox.UseVisualStyleBackColor = true;
            // 
            // btn_OK
            // 
            this.btn_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
          //  this.btn_OK.Image = global::Automatic_Modeling.Properties.Resources.disk;
            this.btn_OK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_OK.Location = new System.Drawing.Point(3, 248);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(145, 24);
            this.btn_OK.TabIndex = 2;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
         //   this.btn_cancel.Image = global::Automatic_Modeling.Properties.Resources.cancel;
            this.btn_cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new System.Drawing.Point(154, 248);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(145, 24);
            this.btn_cancel.TabIndex = 2;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // testStepSkipChkBox
            // 
            this.testStepSkipChkBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.testStepSkipChkBox.AutoSize = true;
            this.tlp_settings.SetColumnSpan(this.testStepSkipChkBox, 2);
            this.testStepSkipChkBox.Location = new System.Drawing.Point(3, 198);
            this.testStepSkipChkBox.Name = "testStepSkipChkBox";
            this.testStepSkipChkBox.Size = new System.Drawing.Size(296, 19);
            this.testStepSkipChkBox.TabIndex = 6;
            this.testStepSkipChkBox.Text = "Consider Test Step Condition";
            this.testStepSkipChkBox.UseVisualStyleBackColor = true;
            // 
            // chk_withParams
            // 
            this.chk_withParams.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chk_withParams.AutoSize = true;
            this.tlp_settings.SetColumnSpan(this.chk_withParams, 2);
            this.chk_withParams.Location = new System.Drawing.Point(3, 223);
            this.chk_withParams.Name = "chk_withParams";
            this.chk_withParams.Size = new System.Drawing.Size(296, 19);
            this.chk_withParams.TabIndex = 7;
            this.chk_withParams.Text = "Count Param Sheet as Test Cases";
            this.chk_withParams.UseVisualStyleBackColor = true;
            // 
            // frm_settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 299);
            this.Controls.Add(this.tlp_settings);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_settings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.frm_settings_Load);
            this.tlp_settings.ResumeLayout(false);
            this.tlp_settings.PerformLayout();
            this.tlp_multiplier.ResumeLayout(false);
            this.tlp_multiplier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_multiplier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlp_settings;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_ignored_macros;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.TableLayoutPanel tlp_multiplier;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown num_multiplier;
        private System.Windows.Forms.CheckBox testCtrlSkipChkBox;
        private System.Windows.Forms.CheckBox paramSheetSkipChkBox;
        private System.Windows.Forms.CheckBox testStepSkipChkBox;
        private System.Windows.Forms.CheckBox chk_withParams;
    }
}