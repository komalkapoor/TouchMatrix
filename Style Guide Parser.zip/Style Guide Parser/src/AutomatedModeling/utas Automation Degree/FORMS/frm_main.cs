﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Text.RegularExpressions;
using Automatic_Modeling.CLASSES;
using Automatic_Modeling.FORMS;
using TreeviewPSD.CLASSES;
using ExcelConnect.CLASSES;
using Excel = Microsoft.Office.Interop.Excel;


namespace Automatic_Modeling
{
    public partial class frm_main : Form
    {
        private string past_ssts_chapter;
        private string Test_Report_Filename;
        private string ssts_filename;
        private string current_ssts_name;
        private string current_ssts_chapter;
        private string temp_input_text = "";
        private string[] Styleguide_Paths;

        private bool isExport;
        private bool isDone;
        private bool isOpenSession;
        private bool isFirstParse = false;
        //hyundai
        public bool Hyundai_ischecked = false;
        // GX code
        //private bool isManualParam;
        // end GX code
        private DataTable dt_report;
        private DataTable dt_Psd;

        private TreeView projectView;

        //private ExcelConnection XLConnection;
        //private Dictionary<string, DataTable> MacroCommandsDictionary;
        //private Dictionary<string, DataTable> ImportedMacroDictionary;
        //private Dictionary<string, DataTable> TestCaseDictionary;
        private HashSet<string> ImageAcqConditions, CompareImagesConditions, SoundAcqConditions, AnalyzeSoundConditions, SemiAutoConditions, DeviceCommandCondition;
        //private List<string> SemiAutoCommandList, ImageAcqCommandList, SoundAcqCommandList, ManualParamCommandList; // GX code
        private List<string> CurrentSSTS_Sheets;

        //## new modeling
        //public List<string> PsdViewerList;
        private List<string> PsdViewerListLcl;

        private List<string> StyleguideHeaderList;

        //private List<string> InputPsdData1_List;
        //private List<string> InputPsdData2_List;

        //private List<string> InputColumn1_List;
        //private List<string> InputColumn2_List;
        //private List<string> InputColumn3_List;
        //private List<string> InputColumn4_List;
        //private List<string> InputColumn5_List;
        //private List<string> InputColumn6_List;
        //private List<string> InputColumn7_List;
        //private List<string> InputColumn8_List;
        //private List<string> InputColumn9_List;
        //private List<string> InputColumn10_List;
        //private List<string> InputColumn11_List;
        //private List<string> InputColumn12_List;
        //private List<string> InputColumn13_List;
        //private List<string> InputColumn14_List;

       // private List<string> InputList[10];
        //## end new modeling

        //private List<string> InputColumn15_List;
        //private List<string> InputColumn16_List;
        //private List<string> InputColumn17_List;
        //private List<string> InputColumn18_List;
        //private List<string> InputColumn19_List;

        // used for open the saved session
        private const int USED_ELEMENTS = 18;
        private int NodeID = 0;
        private int genReportSheetCnt = 0;

        //private static Excel.Workbook myWorkBook = null;
        //private static Excel.Worksheet myWorkSheet = null;
        //private static Excel.Application myAppl = null;


#if COLUMN17
    private List<string> InputColumn17_List;
#endif
#if COLUMN18
    private List<string> InputColumn18_List;
#endif

        private HashSet<string> InvokedParamSheets;
        private string Log = "";

        // limit of number of nested call macro
        private const int MAX_CALLMACRO_CHECK = 5;
        //number of device-related commands 
        private int MAXROW=1;
        private int MAXCOL=1;
        private int current_scansheet = 0;
        private int workbook_count = 0;
        //private int psd_viewer_ctr = 0;
        //private int style_viewer_ctr = 0;
        //private int API_ctr = 1;

        //public param for settings
        //public string Default_multiplier = "50";
        public List<string> Ignored_macros = null;
        public bool ConsiderTestControlSkip = false;
        public bool ConsiderParamSheetSkip = false;
        public bool ConsiderTestStepCondition = false;
        public bool CountParamSheetAsTestCase = false;

        // Imported macro document (to make sure all macros used in an SSTS are recognized, temporarily hard-coded value for sample purpose
        //private string ImportedMacroFile = "";
        private string OutputLogFile = @"log.txt";


        /***
         *  groups of commands to be used for classification
         */

        public string[] colIndex = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        public string[] ReportHeader = { "Tcontrol", "Desc", "X_Px", "Y_Px", "Width", "Height", "Font", "Scale", "Font_Size", "Color_RGB", "Alignment_X", "Alignment_Y", "Resources",
                                         "RESOURCE_ID", "Widget", "Visibility", "API", "Data_Type", "Default_Value", "PConditions", "PValues" };
        //Create for HY


        public string[] HeaderCat= { };


        public int[] Style_Arr;
        ExcelHandler ExcelScan = new ExcelHandler();

        public frm_main()
        {
            InitializeComponent();
            //Styleguide_Path = "";
            Test_Report_Filename = "";
            current_ssts_chapter = "";
            current_ssts_name = "";
            isExport = false;
            isDone = false;

            dt_report = null;

            // InitializeHeaderCategory();
            
            // Retrieve Configuration from File
            Configuration config_Data = new Configuration();
            config_Data.display_data();
           
            HeaderCat = config_Data.config_text_str;
            MAXROW = Convert.ToInt16(config_Data.config_data_1);
            MAXCOL = Convert.ToInt16(config_Data.config_data_2);

            //ExcelHandler myExcel = new ExcelHandler();
            //myExcel.Excel_Manager();
            //PsdViewerList = myExcel.PsdViewerList;

            //Psd_Handler(PsdViewerList);
            //this.projectView = tree;


            //myAppl = new Excel.Application();
            //myAppl.Visible = false;
            //myWorkBook = myAppl.Workbooks.Open("D:\\myWorkspace\\0017_Toyota_CPF\\STYLEGUIDE_488B_04_Patch_02_OUT\\04_SPREAD_SHEETS\\area-a_01.xlsm");

            //int WkSheet = myWorkBook.Worksheets.Count;
            //myWorkSheet = (Excel.Worksheet)myWorkBook.Sheets[WkSheet-1];
            //string sheetname = myWorkSheet.Name;
            //myWorkSheet = (Excel.Worksheet)myWorkBook.Sheets[WkSheet - 2];
            //sheetname = myWorkSheet.Name;

            ////Excel.Range range = (Excel.Range)myWorkSheet.Range[myWorkSheet.Cells[1, 1], myWorkSheet.Cells[10, 10]];
            ////System.Array myData = (System.Array)myWorkSheet.Range["A1", "C5"].Cells.Value;
            //System.Array myData = (System.Array)myWorkSheet.UsedRange.Cells.Value;
            //Excel.Range range = myWorkSheet.UsedRange;


            //initiate condition list for specific command for checking test type
            ImageAcqConditions = new HashSet<string>();
            CompareImagesConditions = new HashSet<string>();
            SoundAcqConditions = new HashSet<string>();
            AnalyzeSoundConditions = new HashSet<string>();
            SemiAutoConditions = new HashSet<string>();
            DeviceCommandCondition = new HashSet<string>();
            InvokedParamSheets = new HashSet<string>();

            //initialize and populate the list of command groups
            InitializeCommandGroups();

            if (CurrentSSTS_Sheets == null) CurrentSSTS_Sheets = new List<string>();

            
            //set data grid view where the result is presented to be copyable
            dgv_report.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithAutoHeaderText;
            dgv_report.AllowUserToOrderColumns = true;
            dgv_report.AllowUserToResizeColumns = true;
            dgv_report.MultiSelect = true;


            //dataGridViewPSD.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            //dataGridViewPSD.ColumnHeadersDefaultCellStyle.BackColor = Color.Gray;
            //dataGridViewPSD.AllowUserToResizeColumns = true;
            //dataGridViewPSD.MultiSelect = true;
        }

        public void InitializeCommandGroups()
        {

            // new modeling
            StyleguideHeaderList = HeaderCat.ToList<string>();
            //InitializeColumn();
            Prepare_Data_Table(true);
        }


//        private void InitializeColumn()
//        {
//            InputPsdData1_List = new List<string>();
//            InputPsdData2_List = new List<string>();

//            InputColumn1_List = new List<string>();
//            InputColumn2_List = new List<string>();
//            InputColumn3_List = new List<string>();
//            InputColumn4_List = new List<string>();

//            InputColumn5_List = new List<string>();
//            InputColumn6_List = new List<string>();
//            InputColumn7_List = new List<string>();
//            InputColumn8_List = new List<string>();

//            InputColumn9_List = new List<string>();
//            InputColumn10_List = new List<string>();
//            InputColumn11_List = new List<string>();
//            InputColumn12_List = new List<string>();

//            InputColumn13_List = new List<string>();
//            InputColumn14_List = new List<string>();
//            InputColumn15_List = new List<string>();
//            InputColumn16_List = new List<string>();

//            InputColumn17_List = new List<string>();
//            InputColumn18_List = new List<string>();
//            InputColumn19_List = new List<string>();

//#if COLUMN17
//            InputColumn17_List = new List<string>();
//#endif
//#if COLUMN18
//            InputColumn18_List = new List<string>();
//#endif


//        }

        //private void reset_InputColumnList()
        //{
        //    InputColumn1_List.Clear();
        //    InputColumn2_List.Clear();
        //    InputColumn3_List.Clear();
        //    InputColumn4_List.Clear();

        //    InputColumn5_List.Clear();
        //    InputColumn6_List.Clear();
        //    InputColumn7_List.Clear();
        //    InputColumn8_List.Clear();

        //    InputColumn9_List.Clear();
        //    InputColumn10_List.Clear();
        //    InputColumn11_List.Clear();
        //    InputColumn12_List.Clear();

        //    InputColumn13_List.Clear();
        //    InputColumn14_List.Clear();
        //    InputColumn15_List.Clear();
        //    InputColumn16_List.Clear();
        //    // new 10-3-2017
        //    InputColumn17_List.Clear();
        //    InputColumn18_List.Clear();
        //    InputColumn19_List.Clear();

        //    InputPsdData1_List.Clear();
        //    InputPsdData2_List.Clear();
        //}

        private void btn_ssts_Click(object sender, EventArgs e)     // Start Parsing
        {

            OpenFileDialog fbd_path = new OpenFileDialog();
            fbd_path.Filter = "MacroEnabled Excel |*.xlsm*|MS Excel 2007 Workbook|*.xlsx*|All files|*.*"; 
            fbd_path.Multiselect = true;
            DialogResult result = fbd_path.ShowDialog();
            if (result == DialogResult.OK)
            {
                reset_page();
                if (fbd_path.FileName != "")
                {
                    Styleguide_Paths = fbd_path.FileNames;
                    foreach (string s in Styleguide_Paths)
                    {
                        txt_ssts.Text += s + " ";
                        txt_ssts.ForeColor = Color.Black;
                    }
                }
            }
        }

        private void btn_genreport_Click(object sender, EventArgs e)    // Browser
        {
            if (txt_ssts.Text != "")
            {
                tstrip_lbl_stat.Text = "";
                dgv_report.DataSource = null;
                //dataGridViewPSD.DataSource = null;
                isExport = false;
                Toggle_Controls(false);
                GetSettingsData();
                Log = "";
                isFirstParse = true;


                //new instance of calculation, should clear all Macro dictionary table
                //MacroCommandsDictionary = new Dictionary<string, DataTable>();
                //reset test case dictionary
                //TestCaseDictionary = null;
                //fetch macros from import excel file, if there is one. Only one time fetch is needed, assuming the batch SSTS use one same Import file
                //no macro required.
                //FetchImportedMacros();
                try
                {
                    bgworker_main.RunWorkerAsync();
                }
                catch
                {
                    //bgworker_main.CancelAsync();
                }
                
            }
            else MessageBox.Show("Please select the Styleguide folder and then try again.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btn_export_Click(object sender, EventArgs e)   // Export excel
        {
            if(txt_ssts.Text == null || txt_ssts.Text == "Enter styleguide path here")
            {
                MessageBox.Show("Please select a valid styleguide document to generate the template",this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (dgv_report.RowCount > 0)
            {
                Test_Report_Filename = "";
                SaveFileDialog sfd_report = new SaveFileDialog();
                sfd_report.Filter = "Microsoft Excel 2007 Workbook (*.xlsm*)|*.xlsm*|All files (*.*)|*.*";
                DialogResult result = sfd_report.ShowDialog();
                if (result == DialogResult.OK)
                {
                    if (sfd_report.FileName != "")
                    {
                        Test_Report_Filename = sfd_report.FileName;// +".xlsx";
                        try
                        {
                            //if (File.Exists(Test_Report_Filename)) File.Delete(Test_Report_Filename);
                            if (File.Exists(Test_Report_Filename) == false)
                                Test_Report_Filename = sfd_report.FileName+".xlsx";
                            isExport = true;
                            Toggle_Controls(false);
                            //bgworker_main.RunWorkerAsync();
                            if (isExport == true)
                            {
                                GenerateReport();
                            }
                        }
                        catch 
                        {
                            MessageBox.Show("An error occured while trying to overwrite existing file.\nPlease close all excel file and try again.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Log += "Error: while trying to write excel\n";
                        }
                    }
                }
            }
        }

        private void Toggle_Controls(bool isEnable)
        {
            btn_ssts.Enabled = isEnable;
            btn_genreport.Enabled = isEnable;
            btn_export.Enabled = isEnable;
            txt_ssts.Enabled = isEnable;
            toolStrip1.Enabled = isEnable;
            fileToolStripMenuItem1.Enabled = isEnable;
            toolToolStripMenuItem1.Enabled = isEnable;
        }

        private void Prepare_Data_Table(bool isNewLaunch)
        {
            //PREPARE DATATABLE
            dt_report = new DataTable();
            PrepareDataTableReport(dt_report);

            //dt_Psd = new DataTable();
            //PreparePSDTableReport(dt_Psd);

            if (isNewLaunch)
            {
                DataView dv = dt_report.DefaultView;
                //dv.Sort = "SSTS asc";
                dgv_report.DataSource = dv.ToTable();
                //dataGridViewPSD.DataSource = dvPsd.ToTable();
            }
        }

        //        private void bgworker_main_DoWork(object sender, DoWorkEventArgs e)
        //        {
        //            try
        //            {
        //#region EXPORT_TEST_REPORT
        //                if (isExport == true) //EXPORT TEST REPORT
        //                {
        //                    try
        //                    {
        //                        GenerateReport();
        //                    }
        //                    catch (Exception exc)
        //                    {
        //                        Log += "Error: Failure during generating the GMTS!\n";
        //                    }
        //                }
        //#endregion

        //#region GENERATE_TEST_REPORT
        //                else if (isExport == false) //GENERATE TEST REPORT
        //                {
        //                    //PREPARE DATATABLE
        //                    //dt_report = new DataTable();
        //                    //PrepareDataTableReport(dt_report);

        //                    //dt_Psd = new DataTable();
        //                    //PreparePSDTableReport(dt_Psd);
        //                    Prepare_Data_Table(false);

        //                    //PrepareDataTableReport_Combined(dt_report);

        //                    //GET ALL SSTS
        //                    //string[] ssts_files = Directory.GetFiles(Styleguide_Path, "*.xls*");                 

        //                    if (Styleguide_Paths == null || Styleguide_Paths.Length == 0 || isOpenSession == true )
        //                    {
        //                        Log += "Error: No Styleguide Selected\n";                       
        //                        return;
        //                    }

        //                    //int ssts_count = ssts_files.Count();
        //                    int ssts_count = Styleguide_Paths.Count();
        //                    int lastSheet = 0;

        //                   // ExcelHandler = new ExcelHandler();



        //                    for (int x = 0; x < ssts_count; x++)
        //                    {

        //                        workbook_count++;
        //                        //ssts_filename = ssts_files[x];
        //                        ssts_filename = Styleguide_Paths[x];
        //                        string ssts_name = Path.GetFileNameWithoutExtension(ssts_filename);
        //                        current_ssts_name = ssts_name;
        //                        // default to 1% 
        //                        int progress_status = 1;

        //                        if (ssts_filename.Contains("~$") == false)
        //                        {
        //                            string constr = "";
        //                            bool is2007 = true;
        //                            //clear list invoked parameter sheets. The list is to track calling param sheet throughout an SSTS
        //                            InvokedParamSheets.Clear();

        //                            if (Path.GetExtension(ssts_filename) == ".xls")
        //                            {
        //                                constr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ssts_filename +
        //                                         ";Extended Properties=\"Excel 8.0;HDR=NO;IMEX=1\"";
        //                                //constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ssts_filename +
        //                                //         ";Extended Properties=\"Excel 8.0;HDR=NO;IMEX=1\"";
        //                                is2007 = false;
        //                            }

        //                            else if (Path.GetExtension(ssts_filename) == ".xlsx")
        //                            {
        //                                constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ssts_filename +
        //                                         ";Extended Properties=\"Excel 12.0 Xml;HDR=NO;IMEX=1\"";
        //                                is2007 = true;
        //                            }
        //                            else
        //                            {
        //                                Log += "Error: Unknown file format for file - "+ssts_filename+" - Please use valid Styleguide format file!\n";
        //                                return;
        //                            }

        //                            XLConnection = new ExcelConnection(constr);

        //                            //GET ALL SHEETS
        //                            string[] style_sheets = XLConnection.ExecuteQuerySheets();
        //                            int ssts_sheets_count = style_sheets.Count();
        //                            bgworker_main.ReportProgress(0);

        //                            //store sheet list to class member variable for global reference by other functions
        //                            List<string> sheet_list = style_sheets.ToList<String>();
        //                            CurrentSSTS_Sheets = sheet_list;

        //                            //read the macro sheet before checking test chapter sheets & find if macro is exist
        //                            //int macroIndex = sheet_list.FindIndex(target => target.ToLower().Contains("macro"));
        //                            //if (macroIndex != -1)
        //                            //{                                
        //                            //    if (MacroCommandsDictionary != null) MacroCommandsDictionary.Clear();
        //                            //    FetchMacros(XLConnection, style_sheets[macroIndex]);
        //                            //    //once Macro sheet of current SSTS is read, we replace all call_macro invocations inside with actual commands
        //                            //    //+//ReplaceAllCallMacro(MacroCommandsDictionary);
        //                            //}

        //                            for (int s = 0; s < ssts_sheets_count; s++)
        //                            {
        //                                current_scansheet = s;
        //                                //GET CHAPTER SHEETS
        //                                if (style_sheets[s].Contains("$"))
        //                                {
        //                                    current_ssts_chapter = style_sheets[s].Replace("$","");   
        //                                    //CHECK IF NOT SETUP OR CLEANUP
        //                                    if (style_sheets[s].ToLower() != "")
        //                                    {
        //                                        //if valid test chapter sheet, we start process
        //                                        DataTable dt_temp = new DataTable();
        //                                        string Input_Text = "";

        //                                        //try
        //                                        //{

        //                                        //    XLConnection.Close();

        //                                        //    if (is2007 == true)
        //                                        //    {
        //                                        //        Input_Text = XLConnection.ExecuteQueryScalar("SELECT * FROM [" + style_sheets[s] + "A1:A55]"); //WHERE F4 = '#uTAS::tstsh'");                                            
        //                                        //    }
        //                                        //    else if (is2007 == false)
        //                                        //    {
        //                                        //        Input_Text = XLConnection.ExecuteQueryScalar("SELECT * FROM [" + style_sheets[s] + "F1:F1]");
        //                                        //    }
        //                                        //}
        //                                        //catch 
        //                                        //{
        //                                        //    //Do nothing 
        //                                        //    //MessageBox.Show(ssts_sheets[s] + ":: Rows: " + dt_temp.Rows.Count.ToString() + " ---- Columns: " + dt_temp.Columns.Count.ToString());
        //                                        //}
        //                                        //MessageBox.Show(ssts_sheets[s] + ":: Rows: " + dt_temp.Rows.Count.ToString() + " ---- Columns: " + dt_temp.Columns.Count.ToString());
        //                                        XLConnection.Close();

        //                                        //CHECK IF TEST CHAPTER                     


        //                                        int cellLoop = MAXCOL;
        //                                        //int validity_f = MAXROW;
        //                                        int cellCtr = 0;
        //                                        int cellCol = 0;
        //                                        bool A1_indicator = false;
        //                                        int endOfdoc_f = 0;                                      




        //                                        for (int cellrow = 1; cellrow < MAXROW; cellrow++)
        //                                        {
        //                                            foreach (string col_t in colIndex)
        //                                            {
        //                                                // get the ID from 26 row
        //                                                //Input_Text = XLConnection.ExecuteQueryScalar("SELECT * FROM [With Spaces$A1:D10]");
        //                                                Input_Text = XLConnection.ExecuteQueryScalar("SELECT * FROM [" + style_sheets[s] + col_t + cellrow + ":" + col_t + cellrow + "]");
        //                                                //Input_Text = XLConnection.ExecuteQueryScalar("SELECT * FROM [" + style_sheets[s] +  "A1:B20]");

        //                                                if (col_t == "A") // A1
        //                                                {
        //                                                    if (Input_Text.ToLower() == "")
        //                                                    {
        //                                                        A1_indicator = true;
        //                                                    }
        //                                                    else
        //                                                    {
        //                                                        // reset indicator
        //                                                        A1_indicator = false;
        //                                                    }
        //                                                }

        //                                                // if first row, then empty string is detected
        //                                                if (cellrow == 1 && Input_Text.ToLower() != "")
        //                                                {
        //                                                    // then we set the limit of the loop. (Column)
        //                                                    cellLoop = ++cellCtr;
        //                                                }
        //                                                else
        //                                                {
        //                                                    if(cellCol >= cellLoop)
        //                                                    {
        //                                                        // exit loop when column reach max
        //                                                        cellCol = 0;
        //                                                        break;
        //                                                    }

        //                                                }

        //                                                // to stored the received input and take it to array
        //                                                try
        //                                                {
        //                                                    Styleguide_Extractor(col_t, Input_Text);                                                          
        //                                                    //ScanAnalyzeCommands();
        //                                                }
        //                                                catch (Exception exc)
        //                                                {
        //                                                    Log += "Failure on Styleguide: " + current_ssts_name + " - Sheet: " + style_sheets[lastSheet] + "\n";
        //                                                    //MessageBox.Show(ssts_sheets[s] + ":: Rows: " + dt_temp.Rows.Count.ToString() + " ---- Columns: " + dt_temp.Columns.Count.ToString());
        //                                                }
        //                                                cellCol++;
        //                                            }

        //                                            // Code to check if more than 3 consecutive empty cell detected, then let it end scanning
        //                                            // Input_Text = XLConnection.ExecuteQueryScalar("SELECT * FROM [" + style_sheets[s] + "A"+ cellrow + ":A" + cellrow +"]");
        //                                            //if(Input_Text.ToLower() == "")
        //                                            if( A1_indicator == true)
        //                                            {
        //                                                endOfdoc_f++;
        //                                                if(endOfdoc_f > 3)
        //                                                {
        //                                                    // validity_f = MAXROW;
        //                                                    progress_status = (s+1)*MAXROW;
        //                                                    cellrow = MAXROW;     
        //                                                }
        //                                            }
        //                                            else 
        //                                            {
        //                                                endOfdoc_f=0;
        //                                            }

        //                                            // to get latest cellrow number status. when max achieve then 
        //                                            progress_status++;

        //                                            try
        //                                            {
        //                                                bgworker_main.ReportProgress(progress_status * 100 / (ssts_sheets_count * MAXROW));
        //                                            }                                   
        //                                            catch (Exception err)
        //                                            {
        //                                                MessageBox.Show("ERROR");
        //                                            }
        //                                        }

        //                                        InputList_processor();

        //                                    }//END IF SSTS SHEET NOT SETUP AND CLEANUP
        //                                }//END IF SSTS SHEET $
        //                            }//END FOR EACH SHEET

        //                            bgworker_main.ReportProgress(100);
        //                        }//END IF MEMORY ~$ FILE 
        //                    }//END FOR EACH SSTS  
        //                }
        //#endregion

        //                isDone = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                isDone = false;
        //                bgworker_main.CancelAsync(); 
        //            }
        //        }



        private void bgworker_main_DoWork(object sender, DoWorkEventArgs e)
        {

            int idx=0;
            // Scan for work book and worksheet first
            // then check how many styleguide present and worksheet
            //bgworker_main.RunWorkerAsync();
            
            if(isFirstParse == true)
            {
                ExcelScan.Init_Excel();
                if(Hyundai_ischecked==true)
                {
                    ExcelScan.Get_Excel_Data_Hyundai(Styleguide_Paths); //for HY
                    PsdViewerListLcl = ExcelScan.PsdViewerList;
                }
                else
                  ExcelScan.Get_Excel_Data(Styleguide_Paths);
                  PsdViewerListLcl = ExcelScan.PsdViewerList;
            }


            //GMTS_Data GMTSData = new GMTS_Data();
            dt_report = new DataTable();
            PrepareDataTableReport(dt_report);

            try
            {
                if (NodeID < 0) NodeID = 0;
                do
                {
                    dt_report.Rows.Add("Run",
                        ExcelScan.GMTData[NodeID][idx].Desc,
                        ExcelScan.GMTData[NodeID][idx].X_px,
                        ExcelScan.GMTData[NodeID][idx].Y_px,
                        ExcelScan.GMTData[NodeID][idx].Width,
                        ExcelScan.GMTData[NodeID][idx].Height,
                        ExcelScan.GMTData[NodeID][idx].Font,
                        ExcelScan.GMTData[NodeID][idx].Scale,
                        ExcelScan.GMTData[NodeID][idx].Font_size,
                        ExcelScan.GMTData[NodeID][idx].Color_RGB,
                        ExcelScan.GMTData[NodeID][idx].Alignment_X,
                        ExcelScan.GMTData[NodeID][idx].Alignment_Y,
                        ExcelScan.GMTData[NodeID][idx].Resource,
                        ExcelScan.GMTData[NodeID][idx].RESOURCE_ID,    // In toyota used as resource ID
                        ExcelScan.GMTData[NodeID][idx].Widget,
                        ExcelScan.GMTData[NodeID][idx].Visibility,
                        ExcelScan.GMTData[NodeID][idx].API,
                        ExcelScan.GMTData[NodeID][idx].Data_Type,
                        ExcelScan.GMTData[NodeID][idx].Default_Value
                        );
                }
                while (++idx < ExcelScan.GMTData[NodeID].Count);
            }
            catch(Exception)
            {
                MessageBox.Show("failed here");
            }

            bgworker_main.ReportProgress(100);
            isDone = true;



            // Then assign the workbook name and subsequent worksheet into a List.
            // then assign the data within the worksheet to another list.

            // eerytime the project tree is selected, then refresh the datagrid with the content store within the Project.
            // This function will show only 1 List at a time.

            // When generating report, then do sth similar with the datagrid, but this time loop through all available data.
            // Each loop shall copy the data into a new sheet, then use the worksheet name as sheet name.

            // Finally prompt completion 
            // If error the stop execution and throw an error.



        }
        
        //private void Styleguide_Extractor(string input, string input_text)
        //{
        //    int number = 0;
        //    string text = "";

        //    if ( input_text == "name")
        //    {
        //        //input_text.ToLookup()
        //    }
        //    switch (input.ToString())

        //    {
        //        case "A": // name 
        //            InputColumn1_List.Add(input_text); // for Descriptions
        //            InputColumn16_List.Add("TRUE"); // for Visibility
        //            InputColumn19_List.Add(""); // for language ID
        //            break;
        //        case "B": // Start 
        //            InputColumn2_List.Add(input_text);
        //            break;
        //        case "C": // X px 
        //            InputColumn3_List.Add(input_text);
        //            break;
        //        case "D": // Y px
        //            InputColumn4_List.Add(input_text);
        //            break;
        //        case "E": // Wdith
        //            InputColumn5_List.Add(input_text);
        //            break;
        //        case "F": // Height
        //            InputColumn6_List.Add(input_text);
        //            break;
        //        case "G": // Font                  
        //            InputColumn7_List.Add(input_text);
        //            if (input_text.ToLower() != "" && !input_text.ToLower().Contains("font"))
        //            {
        //                // Add widget
        //                number= InputColumn7_List.Count();
        //                text = InputColumn1_List.ElementAt(--number);
        //                text = text.Replace(" ","_");

        //                //temp_input_text = ("API_"+text+"_"+API_ctr++);
        //                temp_input_text = ("API_" + text +"_Text");
        //                //temp_input_text = "value=API(\""+"API_" + text + "\")";
        //                InputColumn17_List.Add(temp_input_text);
        //                InputColumn18_List.Add("DATA_TYPE_STRING");

        //                temp_input_text = "BASIC_TEXT";
        //                InputColumn15_List.Add(temp_input_text);
        //            }

        //            break;
        //        case "H": // Scale(width)
        //            InputColumn8_List.Add(input_text);
        //            InputColumn14_List.Add("");
        //            break;

        //        case "I": // FontSize
        //            if (input_text.ToLower().Contains("px") && !input_text.ToLower().Contains("font"))
        //            {
        //                // read only the numeric text in excel, remove other words
        //                input_text = input_text.Remove(2);
        //            }
        //            //temp_input_text = input_text.Replace("px","");
        //            InputColumn9_List.Add(input_text);
        //            break;
        //        case "J": // color RGB
        //            if (input_text.ToLower().Contains(","))
        //            {
        //                // to removed the (,) comma and change to ssb in GMTS
        //                input_text = input_text.Replace(",","");
        //            }
        //            InputColumn10_List.Add(input_text);
        //            break;
        //        case "K": // alignment X
        //            input_text = input_text.ToLower();
        //            InputColumn11_List.Add(input_text);
        //            break;
        //        case "L": // alignment Y
        //            input_text = input_text.ToLower();
        //            InputColumn12_List.Add(input_text);
        //            break;

        //        case "M": // ASset name
        //            input_text = input_text.Replace(" ", "_");
        //            //input_text = input_text.Replace("\n", " ");
                    
        //            //InputColumn13_List.Add(input_text.ToUpper());
        //            InputColumn13_List.Add(input_text);
        //            // For Manual Input (Language ID)
        //            if (input_text.ToLower().Contains("png"))
        //            {

        //                if (input_text.ToLower().Contains("png\n"))
        //                {
        //                    InputColumn15_List.Add("MULTIPLE_ICON");
        //                    temp_input_text = "MULTIPLE_ICON";

        //                    number = InputColumn15_List.Count();
        //                    text = InputColumn1_List.ElementAt(--number);
        //                    text = text.Replace(" ", "_");

        //                    text = "API_"+ text + "_IconSelect";
                            

        //                    InputColumn17_List.Add(text);
        //                    InputColumn18_List.Add("DATA_TYPE_SINT");
        //                    //temp_input_text = "MULTIPLE_ICON";
        //                }
        //                else
        //                {
        //                    InputColumn15_List.Add("ICON");
        //                    temp_input_text = "ICON";
        //                }
                        
        //            }
        //            /* 
        //             * This Part is to Categorized all other None specific type to a default value
        //             * As the list scanner will run this column as the last part, all other non specific type can be declare here.
        //             * In case adding decision is depending on multiple part, add it to the later scan statement for final decision.
        //             */


        //            else if (temp_input_text != "BASIC_TEXT" && temp_input_text != "ICON" && temp_input_text !="MULTIPLE_ICON")
        //            {
        //                InputColumn15_List.Add("CONTAINER");                       
        //            }
        //            if(temp_input_text != "BASIC_TEXT" && temp_input_text != "MULTIPLE_ICON" )
        //            {
        //                InputColumn17_List.Add("");
        //                InputColumn18_List.Add("");
        //            }
        //            temp_input_text = "";
        //            break;
        //            // default: MessageBox.Show("Testing123");
        //            //   break;
        //    }


        //    if (!current_ssts_chapter.ToLower().Contains("sheet") && 
        //        current_ssts_chapter != past_ssts_chapter && 
        //        input_text.ToLower().Contains("psd"))
        //    {
        //        past_ssts_chapter = current_ssts_chapter;
        //        InputPsdData1_List.Add(current_ssts_chapter);
        //        InputPsdData2_List.Add(input_text);
                
        //        //dt_Psd.Rows.Add(current_ssts_chapter);
        //    }
        //}
    
        
        //this is to remove empty list based on XY column
        //private void InputList_processor()
        //{
        //    //int contentCount = InputColumn3_List.Count();
        //    //string[] index_arr = InputColumn3_List.ToArray();

        //    //string test = InputColumn1_List.ElementAt(1);
        //    //dt_report = new DataTable();
        //    //dt_report = null;

        //    while (style_viewer_ctr < InputColumn1_List.Count())
        //    {

        //        // to copy content to excel
        //        if (InputColumn1_List.ElementAt(style_viewer_ctr) != "" && InputColumn1_List.ElementAt(style_viewer_ctr).ToLower() != "name" )
        //            //!InputColumn1_List.ElementAt(style_viewer_ctr).Contains("*"))
        //        {
        //            dt_report.Rows.Add(
        //                            // test control only section
        //                            InputColumn1_List.ElementAt(style_viewer_ctr),
        //                            InputColumn2_List.ElementAt(style_viewer_ctr),
        //                            InputColumn3_List.ElementAt(style_viewer_ctr),
        //                            InputColumn4_List.ElementAt(style_viewer_ctr),

        //                            InputColumn5_List.ElementAt(style_viewer_ctr),
        //                            InputColumn6_List.ElementAt(style_viewer_ctr),
        //                            InputColumn7_List.ElementAt(style_viewer_ctr),
        //                            InputColumn8_List.ElementAt(style_viewer_ctr),

        //                            InputColumn9_List.ElementAt(style_viewer_ctr),
        //                            InputColumn10_List.ElementAt(style_viewer_ctr),
        //                            InputColumn11_List.ElementAt(style_viewer_ctr),
        //                            InputColumn12_List.ElementAt(style_viewer_ctr),

        //                            InputColumn13_List.ElementAt(style_viewer_ctr),
        //                            InputColumn14_List.ElementAt(style_viewer_ctr),
        //                            InputColumn15_List.ElementAt(style_viewer_ctr),
        //                            InputColumn16_List.ElementAt(style_viewer_ctr),

        //                            InputColumn17_List.ElementAt(style_viewer_ctr),
        //                            InputColumn18_List.ElementAt(style_viewer_ctr),
        //                            InputColumn19_List.ElementAt(style_viewer_ctr)
        //                            );
        //        }
                
        //        style_viewer_ctr++;
        //    }
        //    while (psd_viewer_ctr < InputPsdData1_List.Count())
        //    {
        //        dt_Psd.Rows.Add(InputPsdData1_List.ElementAt(psd_viewer_ctr),
        //                        InputPsdData2_List.ElementAt(psd_viewer_ctr));
        //        psd_viewer_ctr++;
        //    }            
        //}
        
        private void bgworker_main_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pbar_main.Value = e.ProgressPercentage;
            tstrip_lbl_stat.Text = "Start analyzing " + current_ssts_name + " - " + current_ssts_chapter +"... | Status: (" + current_scansheet +"/"+ CurrentSSTS_Sheets.Count()+") - Workbook: (" + workbook_count +"/"+ Styleguide_Paths.Count()+")";

        }

        private void bgworker_main_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Toggle_Controls(true);
            if (!isOpenSession)
                tstrip_lbl_stat.Text = "Styleguide Parsing is complete!";
            else
                tstrip_lbl_stat.Text = "Saved session successfully open!";

            StreamWriter logFile = new StreamWriter(OutputLogFile);
            logFile.Write(Log);
            logFile.Close();

            if (isDone == true)
            {
                //ExcelHandler PsdList = new ExcelHandler();
                if(isFirstParse == true)
                {
                    Psd_Handler(PsdViewerListLcl);
                    isFirstParse = false;
                    Hyundai_ischecked = false;//for hy
                }
                

                if (isExport == true)
                {
                    MessageBox.Show("Exporting of GMTS template is complete.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Process.Start(Test_Report_Filename);
                    isExport = false;
                    isDone = false;
                }

                else if (isExport == false)
                {
                    DataView dv = dt_report.DefaultView;
//                    DataView dvPsd = dt_Psd.DefaultView;
                    //dv.Sort = "SSTS asc";
                    dgv_report.DataSource = dv.ToTable();
                   // dataGridViewPSD.DataSource = dvPsd.ToTable();

                    if(isOpenSession == true)
                    {
                        //MessageBox.Show("Session.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        isOpenSession = false;
                    }
                    else
                    {
                        //MessageBox.Show("Styleguide Parsing is complete.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    //Form_plswait plsWait_PopUp = new Form_plswait();
                    //plsWait_PopUp.close_PopUp();

                    //To disable datasorting
                    /*foreach (DataGridViewColumn column in dataGridViewPSD.Columns)
                    {
                        column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }*/
                    foreach (DataGridViewColumn column in dgv_report.Columns)
                    {
                        column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                }
            }
            else //if isDone flag is not true, the process is stopped before the proper ending
            {
                if (isExport == true)
                {
                    MessageBox.Show("An error occured while exporting excel. Please check Log.txt!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (isExport == false)
                {
                    dgv_report.DataSource = dt_report;
                    //dataGridViewPSD.DataSource = dt_Psd;
                    MessageBox.Show("An error occured while Parsing Styleguide. Please check Log.txt!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }                
            }

            pbar_main.Value = 0;
        }

        private void PrepareDataTableReport(DataTable dt_report)
        {
            try
            {
                foreach(string str in ReportHeader)
                {
                    dt_report.Columns.Add(str, typeof(string));
                }
            }
            catch
            {
                MessageBox.Show("Failed to display");
                Log += "Error: while prepare the Header\n";
            }
        }

        private void PreparePSDTableReport(DataTable dt_report)
        {
            try
            {
                dt_Psd.Columns.Add("Worksheet", typeof(string));
                dt_Psd.Columns.Add("PSD", typeof(string));
            }
            catch
            {
                MessageBox.Show("Failed to display");
                Log += "Error: while trying to display the data\n";
            }
        }


        private void GenerateReport()
        {
            string test_report_fn = Test_Report_Filename;
            int idx = 0, rowNumber = 2;
            FileInfo Report_Filename = new FileInfo(test_report_fn);

            using (ExcelPackage ReportPackage = new ExcelPackage(Report_Filename))
            {
                current_ssts_name = PsdViewerListLcl.ElementAt(genReportSheetCnt);
                ExcelWorksheet ReportWorksheet;// = ReportPackage.Workbook.Worksheets.Add(PsdViewerListLcl.ElementAt(genReportSheetCnt)); // this is the file name


                for (int i = 1; i < PsdViewerListLcl.Count; i++)
                {
                    ReportWorksheet = ReportPackage.Workbook.Worksheets.Add(PsdViewerListLcl.ElementAt(i));
                    //ReportPackage.Workbook.Worksheets.Add(PsdViewerListLcl.ElementAt(i));
                    // Param hidden header
                    ReportWorksheet.Cells["A1"].Value = "NbOfRows";
                    ReportWorksheet.Cells["B1"].Formula = "=COUNTIF(A:A,\"Run\")+2";
                    ReportWorksheet.Cells["C1"].Value = "NbOfColumns";
                    ReportWorksheet.Cells["D1"].Formula = "=COUNTA(2:2)";
                    ReportWorksheet.Row(1).Hidden = true;

                    foreach (string hdr in ReportHeader)
                    {
                        string s = colIndex[idx++] + rowNumber.ToString();
                        ReportWorksheet.Cells[s].Value = hdr;
                    }
                    //ReportPackage.Save();
                    idx = 0;
                    //the range of setting the table style
                    ReportWorksheet.Cells["A2:AA2"].Style.Font.Bold = true;
                    ReportWorksheet.Cells["A2:AA2"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    ReportWorksheet.Cells["A2:AA2"].Style.Fill.BackgroundColor.SetColor(Color.Orange);
                    
                            

                    int row_start = 3; //10
                    int col_count = 1;
                    int row_end = ExcelScan.GMTData[--i].Count;

                    for (idx = 0; idx < row_end; idx++)
                    {
                        ReportWorksheet.Cells[row_start, col_count++].Value = "Run";//row_no; //No         
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Desc; //No                        
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].X_px; //SSTS
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Y_px;

                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Width;
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Height; // font size
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Font;
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Scale;

                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Font_size;
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Color_RGB;
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Alignment_X;
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Alignment_Y;
                        
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Resource;
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].RESOURCE_ID; // Data Type
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Widget; // widget
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Visibility; // Visibility

                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].API;    //API
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Data_Type; // Data Type
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].Default_Value; // Default Value
                        ReportWorksheet.Cells[row_start, col_count++].Value = ExcelScan.GMTData[i][idx].PConditions; // Pcon

                        ReportWorksheet.Cells[row_start++, col_count].Value = ExcelScan.GMTData[i][idx].PValues; // PVal
                        ReportWorksheet.Cells.AutoFitColumns();
                        col_count = 1;
                    }
                    i++;
                    idx = 0;
                    
                }

                ReportPackage.Save();
                //ReportWorksheet. = ReportPackage.Workbook.Worksheets[0];
            }       
        }

        //private void GenerateReport()
        //{
        //    string test_report_fn = Test_Report_Filename;
        //    FileInfo Report_Filename = new FileInfo(test_report_fn);
        //    using (ExcelPackage ReportPackage = new ExcelPackage(Report_Filename))
        //    {
        //        //ExcelWorksheet ReportWorksheet = ReportPackage.Workbook.Worksheets.Add("AutomateHMIModeling_" + DateTime.Now.ToString("yyyy_MM_dd"));
        //        //string Worksheet_Name = "";

        //        //if (current_ssts_name == "")
        //        //    current_ssts_name = "sheet1";

        //        current_ssts_name = PsdViewerListLcl.ElementAt(genReportSheetCnt);
        //        ExcelWorksheet ReportWorksheet = ReportPackage.Workbook.Worksheets.Add(current_ssts_name);
        //        try
        //        {
        //            // Param hidden header
        //            ReportWorksheet.Cells["A1"].Value = "NbOfRows";
        //            ReportWorksheet.Cells["B1"].Formula = "=COUNTA(A1:A65535)";
        //            ReportWorksheet.Cells["C1"].Value = "NbOfColumns";
        //            ReportWorksheet.Cells["D1"].Formula = "=COUNTA(2:2)";
        //            ReportWorksheet.Row(1).Hidden = true;

        //            //HEADER
        //            int idx = 0, rowNumber = 2;

        //            foreach(string str in ReportHeader)
        //            {
        //                ReportWorksheet.Cells[colIndex[idx++]+rowNumber].Value = str;
        //            }
        //            //ReportWorksheet.Cells["A2"].Value = "Tcontrol";//0
        //            //ReportWorksheet.Cells["B2"].Value = "IndexID";//1
        //            //ReportWorksheet.Cells["C2"].Value = "Desc";//2
        //            ////ReportWorksheet.Cells["D1"].Value = "Description";//4
        //            ////ReportWorksheet.Cells["E1"].Value = "Function Group";//5
        //            //ReportWorksheet.Cells["D2"].Value = "X_Px";//3
        //            //ReportWorksheet.Cells["E2"].Value = "Y_Px";//4
        //            //ReportWorksheet.Cells["F2"].Value = "Width";//5
        //            //ReportWorksheet.Cells["G2"].Value = "Height";//6
        //            //ReportWorksheet.Cells["H2"].Value = "Font";//7
        //            //ReportWorksheet.Cells["I2"].Value = "Scale";//8
        //            //ReportWorksheet.Cells["J2"].Value = "Font_Size";//9
        //            //ReportWorksheet.Cells["K2"].Value = "Color_RGB";//10
        //            //ReportWorksheet.Cells["L2"].Value = "Alignment_X";//11
        //            //ReportWorksheet.Cells["M2"].Value = "Alignment_Y";//12
        //            //ReportWorksheet.Cells["N2"].Value = "Resources";//13
        //            //ReportWorksheet.Cells["O2"].Value = "RESOURCE_ID";//14
        //            //ReportWorksheet.Cells["P2"].Value = "Widget";//15
        //            //ReportWorksheet.Cells["Q2"].Value = "Visibility";//16
        //            //ReportWorksheet.Cells["R2"].Value = "API";//17
        //            //ReportWorksheet.Cells["S2"].Value = "Data_Type"; //18
        //            //ReportWorksheet.Cells["T2"].Value = "LanguageID"; //19

        //            //the range of setting the table style
        //            ReportWorksheet.Cells["A2:AA2"].Style.Font.Bold = true;
        //            ReportWorksheet.Cells["A2:AA2"].Style.Fill.PatternType = ExcelFillStyle.Solid;
        //            ReportWorksheet.Cells["A2:AA2"].Style.Fill.BackgroundColor.SetColor(Color.Orange);
        //            //ReportWorksheet.Cells["B1:M1"].Style.Font.Color.SetColor(Color.White);
                   
        //            int row_start = 3; //10
        //            int row_end = dgv_report.RowCount;
        //            for (int z = 0; z < row_end; z++)
        //            {
        //                //int row_no = z + 1;

        //                //if (dgv_report[0, z].Value.ToString().ToLower().Contains("name"))
        //                //{
        //                //    z++;
        //                //}

        //                //ReportWorksheet.Cells[row_start, 1].Value = "Run";//row_no; //No         
        //                //ReportWorksheet.Cells[row_start, 2].Value = "";//row_no; //No                        
        //                //ReportWorksheet.Cells[row_start, 3].Value = dgv_report[0, z].Value.ToString(); //SSTS

        //                //try
        //                //{
        //                //    int Numeric;
        //                //    if(int.TryParse(dgv_report[2, z].Value.ToString(), out Numeric))
        //                //    {
        //                //        ReportWorksheet.Cells[row_start, 4].Value = Convert.ToInt16( dgv_report[2, z].Value.ToString());
        //                //        ReportWorksheet.Cells[row_start, 5].Value = Convert.ToInt16( dgv_report[3, z].Value.ToString());
        //                //        ReportWorksheet.Cells[row_start, 6].Value = Convert.ToInt16( dgv_report[4, z].Value.ToString());
        //                //        ReportWorksheet.Cells[row_start, 7].Value = Convert.ToInt16( dgv_report[5, z].Value.ToString());
        //                //    }

        //                //}
        //                //catch
        //                //{
        //                //    Log += "Error: while trying to place integer into template on XY position\n";
        //                //    MessageBox.Show("ERROR while Generate GMTs Template");
        //                //}
        //                ReportWorksheet.Cells[row_start, 1].Value = dgv_report[0, z].Value.ToString();//row_no; //No         
        //                ReportWorksheet.Cells[row_start, 2].Value = dgv_report[1, z].Value.ToString(); //No                        
        //                ReportWorksheet.Cells[row_start, 3].Value = dgv_report[2, z].Value.ToString(); //SSTS
        //                ReportWorksheet.Cells[row_start, 4].Value = dgv_report[3, z].Value.ToString();

        //                ReportWorksheet.Cells[row_start, 5].Value = dgv_report[4, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 6].Value = dgv_report[5, z].Value.ToString(); // font size
        //                ReportWorksheet.Cells[row_start, 7].Value = dgv_report[6, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 8].Value = dgv_report[7, z].Value.ToString();

        //                ReportWorksheet.Cells[row_start, 9].Value = dgv_report[8, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 10].Value = dgv_report[9, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 11].Value = dgv_report[10, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 12].Value = dgv_report[11, z].Value.ToString();
                        
        //                ReportWorksheet.Cells[row_start, 13].Value = dgv_report[12, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 14].Value = dgv_report[13, z].Value.ToString(); // Data Type
        //                ReportWorksheet.Cells[row_start, 15].Value = dgv_report[14, z].Value.ToString(); // Language ID
        //                ReportWorksheet.Cells[row_start, 16].Value = dgv_report[15, z].Value.ToString(); // Language ID

        //                ReportWorksheet.Cells[row_start, 17].Value = dgv_report[16, z].Value.ToString();
        //                ReportWorksheet.Cells[row_start, 18].Value = dgv_report[17, z].Value.ToString(); // Data Type
        //                ReportWorksheet.Cells[row_start, 19].Value = dgv_report[18, z].Value.ToString(); // Language ID
        //                ReportWorksheet.Cells[row_start, 20].Value = dgv_report[19, z].Value.ToString(); // Language ID

        //                //frm_settings Settings = new frm_settings();
        //                //string str_def_multiplier = Settings.Get_Settings("Settings", "Default_Multiplier");

        //                row_start += 1;
        //            }//End For   

        //            ReportWorksheet.Cells.AutoFitColumns();
        //            if (genReportSheetCnt++ < PsdViewerListLcl.Count)
        //            {
        //                //bgworker_main.RunWorkerAsync();
        //            }
        //            else
        //            {
        //                ReportPackage.Save();
        //            }
        //            //ReportPackage.Save();
        //        }
        //        catch (Exception ex)
        //        {
        //        }
                
                
        //    }
        //}

        //private void openToolStripMenuItem1_Click(object sender, EventArgs e)
        //{
        //    string[] tempText_arr;
        //    string tempText = "";
        //    string concatenateText ="";
        //    int tempIndex=0;
        //    int concatIndex = 0;            

        //    OpenFileDialog fbd_path = new OpenFileDialog();
        //    fbd_path.Filter = "AGM session file (*.ses)|*.ses";
        //    fbd_path.Multiselect = true;
        //    DialogResult result = fbd_path.ShowDialog();
        //    if (result == DialogResult.OK)
        //    {
        //        reset_page();
        //        tstrip_lbl_stat.Text = "Please wait session to load...";
        //        Toggle_Controls(false);

        //        if (fbd_path.FileName != "")
        //        {
        //            using (StreamReader sr = new StreamReader(fbd_path.FileName))
        //            {
        //                tempText = sr.ReadToEnd();
        //                tempText_arr = tempText.Split('\n');

        //                //InputColumn_List.AddRange(tempText_arr);
        //            }
        //            for(int k=0; k<tempText_arr.Count(); k++)
        //            {
        //                if (tempIndex == 0 && tempText_arr[k] != "") { InputColumn1_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 1 && tempText_arr[k] != "") { InputColumn2_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 2 && tempText_arr[k] != "") { InputColumn3_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 3 && tempText_arr[k] != "") { InputColumn4_List.Add(tempText_arr[k]); }

        //                else if (tempIndex == 4 && tempText_arr[k] != "") { InputColumn5_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 5 && tempText_arr[k] != "") { InputColumn6_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 6 && tempText_arr[k] != "") { InputColumn7_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 7 && tempText_arr[k] != "") { InputColumn8_List.Add(tempText_arr[k]); }

        //                else if (tempIndex == 8 && tempText_arr[k] != "") { InputColumn9_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 9 && tempText_arr[k] != "") { InputColumn10_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 10 && tempText_arr[k] != "") { InputColumn11_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 11 && tempText_arr[k] != "") { InputColumn12_List.Add(tempText_arr[k]); }
        //                // Asset name
        //                else if (tempIndex == 12 && tempText_arr[k] != "")
        //                {
        //                    // To solve if 2 consecutive long png name is required for concatenation, perform reset.
        //                    if(k == concatIndex)
        //                    {
        //                        concatIndex = 0;
        //                    }
        //                    // perform concatenate when png without /r
        //                    if (tempText_arr[k].ToLower().Contains("png") && (!tempText_arr[k].Contains("\r")) && concatIndex==0)
        //                    {
        //                        // to sync current k index to concatIndex used for merging text
        //                        concatIndex = k;
        //                        do
        //                        {
        //                                concatenateText = string.Concat(concatenateText, tempText_arr[concatIndex]);
        //                        }
        //                        while (!tempText_arr[concatIndex++].Contains("png\r"));
        //                    }

        //                    // to determine if to add normally
        //                    if (concatenateText == "" && k >= concatIndex)
        //                    {
        //                        // add to list with standard text readout from file.
        //                        InputColumn13_List.Add(tempText_arr[k]);
        //                        concatIndex = 0;
        //                    }
        //                    // determine if to add concatenate value
        //                    else if (concatenateText != "" && k < concatIndex)
        //                    {
        //                        // add to list with concatenate text and clear the text.
        //                        InputColumn13_List.Add(concatenateText);
        //                        concatenateText = "";      
        //                    }
                                
        //                } 
        //                else if (tempIndex == 13 && tempText_arr[k] != "") { InputColumn14_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 14 && tempText_arr[k] != "") { InputColumn15_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 15 && tempText_arr[k] != "") { InputColumn16_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 16 && tempText_arr[k] != "") { InputColumn17_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 17 && tempText_arr[k] != "") { InputColumn18_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 18 && tempText_arr[k] != "") { InputPsdData1_List.Add(tempText_arr[k]); }
        //                else if (tempIndex == 19 && tempText_arr[k] != "") { InputPsdData2_List.Add(tempText_arr[k]); }
        //                else { tempIndex++; }
                        
        //            }
        //        }

        //        isDone = true;
        //        isOpenSession = true;
        //        bgworker_main.RunWorkerAsync();
        //        txt_ssts.Text = "\\Styleguide retrieved from saved session";
        //        txt_ssts.ForeColor = Color.LightGray;

        //    }

        //}

        private void configurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Configuration config = new Configuration();
            config.ShowDialog();
        }

        private void dataGridViewPSD_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //var dgv = sender as DataGridView;
            //var check = dgv[e.ColumnIndex, e.RowIndex].Value;

            //dgv_report.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //try
            //{
            //    foreach (DataGridViewRow row in dgv_report.Rows)
            //    {
            //        if(row.Cells[row.Index].Value.ToString().Equals(check))
            //        {
            //            int rowIndex = row.Index;
            //            dgv_report.Rows[1].Selected = false;
            //            dgv_report.Rows[rowIndex].Selected = true;
            //            break;
            //        }
            //    }
            //}
            //catch (Exception exc)
            //{
            //    MessageBox.Show("ERROR\n",exc.Message);
            //}
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    
        private void configurationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Configuration config = new Configuration();
            config.ShowDialog();
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("All DATA will be erased, are you sure?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if(result == DialogResult.Yes)
            {
                reset_page();
                txt_ssts.Text = "Enter styleguide path here";
                txt_ssts.ForeColor = Color.LightGray;
                Prepare_Data_Table(true);
                treeViewPsd.Nodes.Clear();
            }


            //frm_main newForm = new frm_main();
            //newForm.Show();
            //this.Dispose();
        }

        private void reset_page()
        {
            //reset_InputColumnList();
            txt_ssts.Text = "";
            past_ssts_chapter = "";
            workbook_count = 0;
            tstrip_lbl_stat.Text = "";
           // psd_viewer_ctr = 0;
           // style_viewer_ctr = 0;

            Test_Report_Filename = "";
            current_ssts_chapter = "";
            current_ssts_name = "";
            isExport = false;
            isDone = false;
            dt_report = null;
            dt_Psd = null;

            dgv_report.DataSource = null;
            dgv_report.Rows.Clear();
            dgv_report.Refresh();

            treeViewPsd.Nodes.Clear();

            //dataGridViewPSD.DataSource = null;
            //dataGridViewPSD.Rows.Clear();
            //dataGridViewPSD.Refresh();
        }

        private void dgv_report_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // Update the balance column whenever the value of any cell changes.
            MessageBox.Show("WARNING!\n\rCELL value has changed!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Test_Report_Filename = "";
            SaveFileDialog sfd_report = new SaveFileDialog();
            sfd_report.Filter = "AHM saved session (*.ses)|*.ses";
            DialogResult result = sfd_report.ShowDialog();
            if (result == DialogResult.OK)
            {
                if (sfd_report.FileName != "")
                {
                    Test_Report_Filename = sfd_report.FileName;
                    try
                    {
                        if (File.Exists(Test_Report_Filename)) File.Delete(Test_Report_Filename);
                        //isExport = true;
                        //Toggle_Controls(false);
                        saveSession();
                        //bgworker_main.RunWorkerAsync();
                    }
                    catch
                    {
                        MessageBox.Show("An error occured while trying to overwrite existing file.\nPlease close all excel file and try again.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        Log += "Error: while trying to write excel\n";
                    }
                }
            }
        }

        // To save current open environment to text file.
        private void saveSession()
        {

            int row_end = dgv_report.RowCount;
            //int row_endPSD = dataGridViewPSD.RowCount;

            TextWriter saveSes = new StreamWriter(Test_Report_Filename);

            for (int i =0; i< USED_ELEMENTS; i++)
            {
                for (int j = 0; j < row_end; j++)
                {
                    saveSes.WriteLine(dgv_report[i, j].Value.ToString());
                }
                saveSes.Write("\n");
            }
            for (int i = 0; i < 2; i++)
            {
                //for (int j = 0; j < row_endPSD; j++)
                //{
                   // saveSes.WriteLine(dataGridViewPSD[i, j].Value.ToString());
                //}
                saveSes.Write("\n");
            }

            saveSes.Close();

        }

        private void txt_ssts_MouseClick (object sender, MouseEventArgs e)
        {
            if(txt_ssts.Text == "Enter styleguide path here")
            {
                txt_ssts.Text = "";
            }
            else if(txt_ssts.Text == "\\Styleguide retrieved from saved session")
            {
                txt_ssts.Text = "";
            }
            
        }

        private void txt_ssts_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("GMT Styleguide Parser 2017 \n\rVersion 2.0\n\n\rContinental Automotive Singapore"
                , this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void treeViewPsd_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string NodeText = "";
            


            NodeID = -1;
            if (treeViewPsd.SelectedNode.IsSelected)
            {
                //reset_page();
                dt_report = null;
                dgv_report.DataSource = null;
                dgv_report.Rows.Clear();
                NodeText = treeViewPsd.SelectedNode.Text;

                foreach(string nodeName in PsdViewerListLcl)
                {
                    if(nodeName == NodeText)
                    {
                        // now node ID is locked and this to be use by database
                        break;
                    }
                    NodeID++;
                }
                // start to display the new data row
                bgworker_main.RunWorkerAsync();
                
            }
        }

        private void radioButton1_CheckedChange(object sender, EventArgs e)//check for Hyundai code to be executed
        {
            if (radioButton1.Checked)
            {
                //MessageBox.Show("this is Hyundai!");
                Hyundai_ischecked = true;
            }
        }

        private void GetTestStepsCallMacro(string macroName, Dictionary<string,DataTable> targetMacroDict,ref int depthCounterCallMacro, ref DataTable dt_next_callmacro)
        {
            DataTable dt_source = null;
            try
            {
                //check  in SSTS macro dictionary first, if not found we query imported macro dictionary
                dt_source = targetMacroDict[macroName.ToLower()];
            }
            catch(Exception ex)
            {
                //MessageBox.Show("Can't find macro name: " + macroName);
                Console.WriteLine("GetTestStepsCallMacro: Cant find in SSTS macro table - " + macroName);
            }

            if(dt_source == null)
            {
                try
                {
                    //dt_source = ImportedMacroDictionary[macroName.ToLower()];
                }
                catch (Exception ex)
                {
                    //MessageBox.Show("Can't find macro name: " + macroName);
                    Console.WriteLine("GetTestStepsCallMacro: Cant find in Imported macro table - " + macroName);
                }
            }
            

            if (dt_source == null) return;

            /*
            DataTable dt_return = new DataTable();
            dt_return.Columns.Add("Conditions", typeof(string));
            dt_return.Columns.Add("Commands", typeof(string));
            dt_return.Columns.Add("Parameters", typeof(string));
            */

            //increment nested callmacro counter every time we call GetTestStepsCallMacro function
            depthCounterCallMacro += 1;

            if(depthCounterCallMacro <= MAX_CALLMACRO_CHECK)
            {
                for (int i = 0; i < dt_source.Rows.Count; i++)
                {
                    string currCmd = dt_source.Rows[i][1].ToString();
                    //the command is not call_macro, we count it in
                    if (currCmd.ToLower() != "call_macro")
                    {
                        if (dt_next_callmacro == null)
                        {
                            dt_next_callmacro = new DataTable();
                            dt_next_callmacro.Columns.Add("Conditions", typeof(string));
                            dt_next_callmacro.Columns.Add("Commands", typeof(string));
                            dt_next_callmacro.Columns.Add("Parameters", typeof(string));
                        }
                        dt_next_callmacro.Rows.Add(dt_source.Rows[i][0], dt_source.Rows[i][1], dt_source.Rows[i][2]);
                    }
                    // if it's call_macro and still not exceeding the nested call macro limit, we get the commands inside this macro first (depth-first) before proceeding to next command
                    else
                    {
                        GetTestStepsCallMacro(dt_source.Rows[i][2].ToString(), targetMacroDict, ref depthCounterCallMacro, ref dt_next_callmacro);
                        //decrease the counter after we succesfully return from the traverse of nested call_macro
                        depthCounterCallMacro -= 1;
                    }
                }
            } //endif depthCounterCallMacro <= MAX_CALLMACRO_CHECK            
        }

        private void GetSettingsData()
        {
            frm_settings settings = new frm_settings();
            settings.ReadSettingsData();

            Ignored_macros = settings.IgnoredMacros.Split(',').ToList<string>();

            //clean the ignore macros as string

            //Default_multiplier = settings.DefaultMultiplier;
            ConsiderParamSheetSkip = (settings.ParamSheetSkipFlag == "1" ? true : false);
            ConsiderTestControlSkip = (settings.TestControlSkipFlag == "1" ? true : false);
            ConsiderTestStepCondition = (settings.TestStepCondFlag == "1" ? true : false);
            CountParamSheetAsTestCase = (settings.CountParamSheetFlag == "1" ? true : false);
        }
        
        private void btn_settings_Click(object sender, EventArgs e)
        {
            frm_settings settings = new frm_settings();
            settings.ShowDialog();            
        }

        public void Psd_TreeView_Init(List<string> workbook)
        {
            
            TreeNode psdNode = new TreeNode();
            psdNode.Name = "psdnode";
            psdNode.Text = "Test";

            //projectView.Nodes.Add(psdNode);
            //myProject.projectView.Nodes.Add(psdNode);
            treeViewPsd.Nodes.Add(workbook[0]);
            //treeViewPsd.EndUpdate();

            //int idx = workbook.Count();
            //if (idx != 0)
            {
               // psdNode.Text = workbook.ElementAt(0);
                //treeViewPsd.Nodes.Add(psdNode);
                //psdNode.Nodes.Add(psdNode.Text);
            }
        }

        // each call will create this structure
        private void Psd_Handler(List<string> workbook)
        {
           // ExcelHandler wBCount = new ExcelHandler();
           // int index = wBCount.workBookName.Count();
            Psd_TreeView_Init(workbook);

            for (int i=1; i<workbook.Count; i++)
            {               
                treeViewPsd.Nodes[0].Nodes.Add(workbook[i]);
                treeViewPsd.ExpandAll();


            }


        }
    }
}
