﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Automatic_Modeling.CLASSES;
using System.IO;
using System.Reflection;


namespace Automatic_Modeling.FORMS
{

    public partial class Configuration : Form
    {
        public string[] config_HeaderArray;
        public int config_MaxCol;
        public int config_MaxRow;
        private string config_browse_file = "AHMconfig.cfg";
        public string[] config_text_str;

        public string config_data_1;
        public string config_data_2;

 
        public Configuration()
        {
            InitializeComponent();
            display_data();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            //if(!isCfgFileDetected)  
            using (StreamWriter wr = new StreamWriter(config_browse_file))
            {
                wr.Write(richTextBox1.Text);// Write everything to file if changes
            } 
        }

        public void Styleguide_Config_Data()
        {
            config_HeaderArray= richTextBox1.Lines;
            //config_MaxRow = int.Parse(textBox1.Text);
            //config_MaxCol = int.Parse(textBox2.Text);
        }

         private void btnOK_Click_1(object sender, EventArgs e)
        {
            Styleguide_Config_Data();
            this.Close();
            frm_main InitHeaderCat = new frm_main();
            InitHeaderCat.HeaderCat = config_HeaderArray;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //browse_config_file();
        }

        private void buttonCfg_Click(object sender, EventArgs e)
        {
            browse_config_file();
        }

        private void browse_config_file()
        {
            string tempText;

            config_browse_file = "";
            OpenFileDialog config_path = new OpenFileDialog();
            config_path.Filter = "AHM config file (*.cfg)|*.cfg";
            DialogResult result = config_path.ShowDialog();

            textBox3_cfg.Text = config_path.FileName;
            if (result == DialogResult.OK)
            {

                if (config_path.FileName != "")
                {
                    config_browse_file = config_path.FileName;
                    try
                    {
                        using (StreamReader sr = new StreamReader(config_browse_file))
                        {
                            richTextBox1.Text = sr.ReadToEnd();
                            tempText = richTextBox1.Text;
                            config_text_str = tempText.Split('\n');
                        }

                        for (int i = 0; i < config_text_str.Count(); i++)
                        {
                            if (config_text_str[i].Contains("MAXROW"))
                            {
                                //textBox1.Text = config_text_str[i].Replace("MAXROW", "");
                                //config_data_1 = textBox1.Text;
                            }
                            else if (config_text_str[i].Contains("MAXCOL"))
                            {
                                //textBox2.Text = config_text_str[i].Replace("MAXCOL", "");
                                //config_data_2 = textBox2.Text;
                            }
                        }
                    }

                    catch
                    {
                        MessageBox.Show("An error occured while trying to retrieve the config file.\nPlease try again with correct config file.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
        }


        public void display_data()
        {
            string tempText;

            var outputDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
            var configPath = Path.Combine(outputDirectory, config_browse_file);
            string configFilePath = new Uri(configPath).LocalPath;

            try
            {
                using (StreamReader sr = new StreamReader(configFilePath))
                {
                    richTextBox1.Text = sr.ReadToEnd();
                    tempText = richTextBox1.Text;
                    config_text_str = tempText.Split('\n');
                }

                for (int i = 0; i < config_text_str.Count(); i++)
                {
                    if (config_text_str[i].Contains("MAXROW"))
                    {
                        //textBox1.Text = config_text_str[i].Replace("MAXROW", "");
                        //config_data_1 = textBox1.Text;
                    }
                    else if (config_text_str[i].Contains("MAXCOL"))
                    {
                        //textBox2.Text = config_text_str[i].Replace("MAXCOL", "");
                        //config_data_2 = textBox2.Text;
                    }
                }

            }
            catch
            {
                MessageBox.Show("An error occured while trying to retrieve the config file.\nPlease try again with correct config file.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                browse_config_file();
                
            }
        }
    }
}
