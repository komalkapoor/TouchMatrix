﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Automatic_Modeling.CLASSES;
using System.Globalization;

namespace Automatic_Modeling.FORMS
{
    public partial class frm_settings : Form
    {
        private string uAD_Ini = Path.GetDirectoryName(Application.ExecutablePath) + @"\settings.ini";
        private IniConnection Ini_Connect;
        public frm_settings()
        {
            InitializeComponent();
            Create_uAD_Ini();
            Ini_Connect = new IniConnection(uAD_Ini);
        }
        /***
         * Settings property in memory (no need for re-reading setting ini file)
         */
        public string IgnoredMacros
        {
            set;
            get;
        }
        public string DefaultMultiplier
        {
            set;
            get;
        }
        public string TestControlSkipFlag
        {
            set;
            get;
        }
        public string ParamSheetSkipFlag
        {
            set;
            get;
        }
        public string TestStepCondFlag
        {
            set;
            get;
        }
        public string CountParamSheetFlag
        {
            set;
            get;
        }

        public void Create_uAD_Ini()
        {
            if (File.Exists(uAD_Ini) == false)
            {
                StringBuilder uAD_Ini_Data = new StringBuilder();
                uAD_Ini_Data.AppendLine(";#########################################################################");
                uAD_Ini_Data.AppendLine(";Automatic Modeling Tool");
                uAD_Ini_Data.AppendLine(";Developed by: Ga Xiang");
                uAD_Ini_Data.AppendLine(";#########################################################################");
                uAD_Ini_Data.AppendLine(";");
                uAD_Ini_Data.AppendLine("[Settings]");
                uAD_Ini_Data.AppendLine("Ignored_Macros=");
                uAD_Ini_Data.AppendLine("Default_Multiplier=50");
                uAD_Ini_Data.AppendLine("ConsiderTestControlEnableSkipFlag=1");
                uAD_Ini_Data.AppendLine("ConsiderParamSheetRunSkipFlag=1");
                uAD_Ini_Data.AppendLine(";");
                uAD_Ini_Data.AppendLine(";");
                File.WriteAllText(uAD_Ini, uAD_Ini_Data.ToString());
            }
        }

        public string Get_Settings(string Section, string Key)
        {
            string value = "";
            value = Ini_Connect.IniReadValue(Section, Key);
            return value;
        }

        public bool Set_Setting(string Section, string Key, string Value)
        {
            bool isOk = true;
            try
            {
                Ini_Connect.IniWriteValue(Section, Key, Value);
            }
            catch { isOk = false; }
            return isOk;
        }

        public void ReadSettingsData()
        {
            string ignored_macros = Get_Settings("Settings", "Ignored_Macros");
            txt_ignored_macros.Text = ignored_macros;

            string default_multiplier = Get_Settings("Settings", "Default_Multiplier");
            float def_mult = 50;
            if (float.TryParse(default_multiplier, out def_mult))
            {
                num_multiplier.Value = Convert.ToDecimal(def_mult);
            }
            else num_multiplier.Value = 50;

            //get the value for Enable/Skip flag check
            string considerEnableSkipFlag = Get_Settings("Settings", "ConsiderTestControlEnableSkipFlag");
            testCtrlSkipChkBox.Checked = considerEnableSkipFlag == "1" ? true : false;
            
            //get the value for Run/Skip flag check
            string considerRunSkipFlag = Get_Settings("Settings", "ConsiderParamSheetRunSkipFlag");
            paramSheetSkipChkBox.Checked = considerRunSkipFlag == "1" ? true : false;
            
            //get the value for Test Step condition flag check
            string considerTestStepConditionFlag = Get_Settings("Settings", "ConsiderTestStepConditionFlag");
            testStepSkipChkBox.Checked = considerTestStepConditionFlag == "1" ? true : false;

            //get the value for Test Step condition flag check
            string countParamSheetTestCaseFlag = Get_Settings("Settings", "CountParamSheetAsTestCasesFlag");
            chk_withParams.Checked = countParamSheetTestCaseFlag == "1" ? true : false;

            //set public Setting's properties
            IgnoredMacros = ignored_macros;
            DefaultMultiplier = default_multiplier;
            TestControlSkipFlag = considerEnableSkipFlag;
            ParamSheetSkipFlag = considerRunSkipFlag;
            TestStepCondFlag = considerTestStepConditionFlag;
            CountParamSheetFlag = countParamSheetTestCaseFlag;
        }

        private void frm_settings_Load(object sender, EventArgs e)
        {
            ReadSettingsData();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            bool isOK=true;
            string ignored_macros = txt_ignored_macros.Text;
            try
            {
                isOK = Set_Setting("Settings", "Ignored_Macros", ignored_macros);
                if (!isOK) throw new Exception("Ignored Macros");

                isOK = Set_Setting("Settings", "Default_Multiplier", num_multiplier.Value.ToString());
                if (!isOK) throw new Exception("Default Multiplier");

                //if setting test control flag is not working well, close the window
                string considerEnableSkipFlag = (testCtrlSkipChkBox.Checked == true ? "1" : "0");
                isOK = Set_Setting("Settings", "ConsiderTestControlEnableSkipFlag", considerEnableSkipFlag);
                if (!isOK) throw new Exception("Test Control Enable/Skip Flag");

                //if setting param sheet flag is not working well, close the window
                string considerRunSkipFlag = (paramSheetSkipChkBox.Checked == true ? "1" : "0");
                isOK = Set_Setting("Settings", "ConsiderParamSheetRunSkipFlag", considerRunSkipFlag);
                if (!isOK) throw new Exception("Param Sheet Run/Skip Flag");

                //if setting test step cond flag is not working well, close the window
                string considerTestStepConditionFlag = (testStepSkipChkBox.Checked == true ? "1" : "0");
                isOK = Set_Setting("Settings", "ConsiderTestStepConditionFlag", considerTestStepConditionFlag);
                if (!isOK) throw new Exception("Test Step Condition Flag");

                //if setting test step cond flag is not working well, close the window
                string countParamSheetTestCaseFlag = (chk_withParams.Checked == true ? "1" : "0");
                isOK = Set_Setting("Settings", "CountParamSheetAsTestCasesFlag", countParamSheetTestCaseFlag);
                if (!isOK) throw new Exception("Count Param Sheet Test Cases Flag");

                //set public property
                IgnoredMacros = ignored_macros;
                DefaultMultiplier = num_multiplier.Value.ToString();
                TestControlSkipFlag = considerEnableSkipFlag;
                ParamSheetSkipFlag = considerRunSkipFlag;
                TestStepCondFlag = considerTestStepConditionFlag;
                CountParamSheetFlag = countParamSheetTestCaseFlag;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured while saving the Settings: " + ex.ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                this.Close();
            }
        }
    }
}
