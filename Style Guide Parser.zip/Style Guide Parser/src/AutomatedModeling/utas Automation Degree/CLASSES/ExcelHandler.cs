﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Automatic_Modeling;
using System.Text.RegularExpressions;
using Excel = Microsoft.Office.Interop.Excel;
using System.Diagnostics;

namespace ExcelConnect.CLASSES
{
   enum param { Widget, API, DataType, AlignmentY, FontSize, Font, Icon, ColorRGB };//array number equivalent

    public class ExcelHandler
    {
        //private variabless
        private static Excel.Workbook myWorkBook = null;
        private static Excel.Worksheet myWorkSheet = null;
        private static Excel.Application myAppl = null;
        private int workBookIdx;//index

        public List<string> PsdViewerList;
        public List<string> workBookNameList;

        public List<string> data;       
        
        public List<GMTS_Data> GMTSparam = new List<GMTS_Data>();//build class for gmts process data 
        public List<List<GMTS_Data>> GMTData = new List<List<GMTS_Data>>();
        
        System.Array myData;//TY
        System.Array rawData;//HY
        private string[] paramData = new string[(int)param.ColorRGB + 1];
        //For Toyota
        private string[] FontID_Trim = {"Tfont_1010b_T2_MonospacedNormal", "Tfont_1010b_MonospacedRegular_Monospaced",
                                        "Tfont_1010bT2B","Tfont_1010bT2"};
        //For Hyundai
        private string[] FontID_Trim_HY = {"DINNextPro_for_Hyundai", "DINNextPro_for_Hyundai-Medium",
                                        "DINNextPro_for_Hyundai-Cond"};
        //For Hyundai
        public void extractDataArea()
        {
            //Area
            int c1, c2, c3;
            string[] aColumn = null;
            string[] cColumn = null;
            string[] dColumn = null;
            List<string> alstColumn = new List<string>();
            List<string> clstColumn = new List<string>();
            List<string> dlstColumn = new List<string>();
            //place all 3 lists to 1 AREA_list
            List<List<string>> AREA_list = new List<List<string>>();
            AREA_list.Add(alstColumn);
            AREA_list.Add(clstColumn);
            AREA_list.Add(dlstColumn);
            /*------------------Start sheet Area---------------------------------*/
            //locate sheet name "Area"
            if (myWorkSheet.Name.ToLower() == "area")
            {
                Microsoft.Office.Interop.Excel.Range range_1 = (Microsoft.Office.Interop.Excel.Range)myWorkSheet.Cells[1, 1];
                string cellValue = range_1.Value.ToString();
                // get used range of column A
                //Range range_1 = xlSheet.UsedRange.Columns["A", Type.Missing];

                // get number of used rows in column A
                int rngCount_1 = range_1.Rows.Count;

                //for col A
                for (c1 = 1; c1 <= rngCount_1; c1++)
                {
                    if (c1 >= 3 && c1 <= 8)
                    {
                        alstColumn.Add(myWorkSheet.Cells[c1 + 2, "A"].Value.ToString());
                        aColumn = alstColumn.ToArray();//get all the area names
                   }                        
                }

                //for col C
                for (c2 = 1; c2 <= rngCount_1; c2++)
                {
                    if (c2 >= 3 && c2 <= 8)
                    {
                        clstColumn.Add(myWorkSheet.Cells[c2 + 2, "C"].Value.ToString());
                        cColumn = clstColumn.ToArray();//get all the C values
                    }                       
                }
                //for col D
                for (c3 = 1; c3 <= rngCount_1; c3++)
                {
                    if (c3 >= 3 && c3 <= 8)
                    {
                        dlstColumn.Add(myWorkSheet.Cells[c3 + 2, "D"].Value.ToString());
                        dColumn = dlstColumn.ToArray();//get all the D values 
                    }                      
                }
            }           
        }
        /*------------------End sheet Area-----------------------------------*/
        /*------------------Start sheet Font_Color_Layout--------------------*/
        public string[,] extractDataRGB()
        {
            int c4, c5, c6, c7;
            string[] a_1Column = null;
            string[] c_1Column = null;
            string[] d_1Column = null;
            string[] e_1Column = null;
            List<string> a_1lstColumn = new List<string>();
            List<string> c_1lstColumn = new List<string>();
            List<string> d_1lstColumn = new List<string>();
            List<string> e_1lstColumn = new List<string>();
            //place all 4 lists to 1 RGB_list
            //List<List<string>> RGB_list = new List<List<string>>();
            string[,] RGB_dataArray = new string[24,4];

            myWorkSheet = myWorkBook.ActiveSheet;

            //locate sheet name "font_color_layout"
            if (myWorkSheet.Name.ToLower() == "font_color_layout")
            {
                // get used range of column A
                Microsoft.Office.Interop.Excel.Range range_2 = myWorkSheet.UsedRange.Columns["A", Type.Missing];

                // get number of used rows in column A
                int rngCount_2 = range_2.Rows.Count;
                
                    //for col A
                    for (c4 = 1; c4 <= rngCount_2; c4++)
                    {
                        if (c4 >= 3 && c4 <= 27)
                        {
                            a_1lstColumn.Add(myWorkSheet.Cells[c4, "A"].Value.ToString());
                            a_1Column = a_1lstColumn.ToArray();//get all the font_color names
                        }
                    }                             
                //for col C
                for (c5 = 1; c5 <= rngCount_2; c5++)
                {
                    if (c5 >= 3 && c5 <= 27)
                    {
                        c_1lstColumn.Add(myWorkSheet.Cells[c5, "C"].Value.ToString());
                        c_1Column = c_1lstColumn.ToArray();//get all the C values
                    }
                }
                //for col D
                for (c6 = 1; c6 <= rngCount_2; c6++)
                {
                    if (c6 >= 3 && c6 <= 27)
                    {
                        d_1lstColumn.Add(myWorkSheet.Cells[c6, "D"].Value.ToString());
                        d_1Column = d_1lstColumn.ToArray();//get all the D values 
                    }                      
                }
                //for col E
              for (c7 = 1; c7 <= rngCount_2; c7++)
                {
                    if (c7 >= 3 && c7 <= 27)
                    {
                        e_1lstColumn.Add(myWorkSheet.Cells[c7, "E"].Value.ToString());
                        e_1Column = e_1lstColumn.ToArray();//get all the E values
                    }                       
                }
                //RGB_list.Add(a_1lstColumn);
                //RGB_list.Add(c_1lstColumn);
                //RGB_list.Add(d_1lstColumn);
                //RGB_list.Add(e_1lstColumn);
                int counter = 0; 
            for(int col=0; col<4; col++)
                {
                    for(int row=0; row<24; row++)
                    {
                        switch (counter)
                        {
                            case 0:
                                RGB_dataArray[row, col] = a_1Column[row];
                                break;
                            case 1:
                                RGB_dataArray[row, col] = c_1Column[row];
                                break;
                            case 2:
                                RGB_dataArray[row, col] = d_1Column[row];
                                break;
                            case 3:
                                RGB_dataArray[row, col] = e_1Column[row];
                                break;
                            default:
                                break;
                        }     
                    }
                    counter++;
                }

            }
            return RGB_dataArray;
        }
        /*------------------End sheet Font_Color_Layout--------------------*/
        /*------------------Start sheet Font_Type--------------------------*/
        //public string[,] extractDataFontType()
        public void extractDataFontType()
        {
            //Font_type
            int c8, c9, c10, c11, c12, c13, c14;
            string[] a_2Column = null;
            string[] b_2Column = null;
            string[] c_2Column = null;
            string[] d_2Column = null;
            string[] g_2Column = null;
            string[] h_2Column = null;
            string[] i_2Column = null;
            List<string> a_2lstColumn = new List<string>();
            List<string> b_2lstColumn = new List<string>();
            List<string> c_2lstColumn = new List<string>();
            List<string> d_2lstColumn = new List<string>();
            List<string> g_2lstColumn = new List<string>();
            List<string> h_2lstColumn = new List<string>();
            List<string> i_2lstColumn = new List<string>();
            if (myWorkSheet.Name.ToLower() == "font_type")
            {
                // get used range of column A
                Microsoft.Office.Interop.Excel.Range range_3 = myWorkSheet.UsedRange.Columns["A", Type.Missing];
                
                // get number of used rows in column A
                int rngCount_3 = range_3.Rows.Count;

                //for col A
                for (c8 = 1; c8 <= rngCount_3; c8++)
                {
                    if (c8 >= 3 && c8 <= 34)
                    {
                        a_2lstColumn.Add(myWorkSheet.Cells[c8, "A"].Value.ToString());
                        a_2Column = a_2lstColumn.ToArray();//get all the font_color names
                    }
                }

                //for col B
                for (c9 = 1; c9 <= rngCount_3; c9++)
                {
                    if (c9 >= 3 && c9 <= 34)
                    {
                        b_2lstColumn.Add(myWorkSheet.Cells[c9, "B"].Value.ToString());
                        b_2Column = b_2lstColumn.ToArray();//get all the B values
                    }
                }

                //for col C
                for (c10 = 1; c10 <= rngCount_3; c10++)
                {
                    if (c10 >= 3 && c10 <= 34)
                    {
                        c_2lstColumn.Add(myWorkSheet.Cells[c10, "C"].Value.ToString());
                        c_2Column = c_2lstColumn.ToArray();//get all the C values
                    }
                }
                //for col D
                for (c11 = 1; c11 <= rngCount_3; c11++)
                {
                    if (c11 >= 3 && c11 <= 34)
                    {
                        d_2lstColumn.Add(myWorkSheet.Cells[c11, "D"].Value.ToString());
                        d_2Column = d_2lstColumn.ToArray();//get all the D values  
                    }
                }
                //for col G
                for (c12 = 1; c12 <= rngCount_3; c12++)
                {
                    if (c12 >= 3 && c12 <= 34)
                    {
                        g_2lstColumn.Add(myWorkSheet.Cells[c12, "G"].Value.ToString());
                        g_2Column = g_2lstColumn.ToArray();//get all the G values   
                    }
                }

                //for col H
                for (c13 = 1; c13 <= rngCount_3; c13++)
                {
                    if (c13 >= 3 && c13 <= 34)
                    {
                        h_2lstColumn.Add(myWorkSheet.Cells[c13, "H"].Value.ToString());
                        h_2Column = h_2lstColumn.ToArray();//get all the H values
                    }
                }

                //for col I
                for (c14 = 1; c14 <= rngCount_3; c14++)
                {
                    if (c14 >= 3 && c14 <= 34)
                    {
                        i_2lstColumn.Add(myWorkSheet.Cells[c14, "I"].Value.ToString());
                        i_2Column = i_2lstColumn.ToArray();//get all the I values  
                    }
                }

            }
        }
        /*------------------End sheet Font_Type--------------------------*/
        //end HY
        public void Init_Excel()
        {
            myAppl = new Excel.Application();
            myAppl.Visible = false;
            PsdViewerList = new List<string>();
            workBookNameList = new List<string>();
        }

        public void Close_Excel()
        {
            myWorkBook.Close();
            myAppl.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(myWorkBook);
        }

        private void Init_Param_Object()
        {
            List<string> Desc = new List<string>();
        }

        // Each time complete 1 file parse then only revisit this function
        public void Excel_Manager(string[] path)
        {
            //Init_Excel();
            Get_Excel_Data(path);
        }

        //Hyundai starts here
        public void Get_Excel_Data_Hyundai(string[] path)
        {
            int xLength, xDepth, xlenCtr = 1, start_row = 3;//styleguide shows this row number is starting point of data
            string[,] getRGB = new string[24, 4];
            workBookIdx = path.Count();
            List<string> data = new List<string>();
           
            myWorkBook = myAppl.Workbooks.Open(path[--workBookIdx]);
            PsdViewerList.Add(myWorkBook.Name);

            getRGB = extractDataRGB(); //call rgb extraction method 

            for (int i = 1; i <= myWorkBook.Worksheets.Count; i++)
            {
                myWorkSheet = (Excel.Worksheet)myWorkBook.Sheets[i];
                if (myWorkSheet.Name.ToLower() != "history" && myWorkSheet.Name.ToLower() != "text_layout" && myWorkSheet.Name.ToLower() != "parse_" && myWorkSheet.Name.ToLower() != "area" && myWorkSheet.Name.ToLower() != "font_type" && myWorkSheet.Name.ToLower() != "font_color_layout")//omit the sheet dont want to read change
                {
                    rawData = (System.Array)myWorkSheet.UsedRange.Cells.Value;
                    xLength = rawData.GetLength(1);  // column
                    xDepth = rawData.GetLength(0);   // row
                   
                    // Do some process to handle the data
                    for (int j = start_row; j <= xDepth; j++)
                    {
                        do
                        {
                            if (rawData.GetValue(j, xlenCtr) == null)
                            {
                                rawData.SetValue("", j, xlenCtr);
                            }
                            xlenCtr++;
                        }
                        while (xlenCtr <= xLength);
                        xlenCtr = 2;
                    }
                    List<GMTS_Data> GMTSparam = new List<GMTS_Data>();

                    do
                    {
                        //if (rawData.GetValue(start_row, 10).ToString() != "") //Font
                        //{
                        //    paramData[(int)param.Widget] = "BASIC_TEXT";
                        //    paramData[(int)param.API] = myWorkSheet.Name + "_" + rawData.GetValue(start_row, 3).ToString();//raw data
                        //    paramData[(int)param.DataType] = "DATA_TYPE_STRING";
                        //    paramData[(int)param.Icon] = "";

                        //}
                        //else if (rawData.GetValue(start_row, 13).ToString() != "")//image name
                        //{
                        //    paramData[(int)param.Widget] = "ICON";
                        //    paramData[(int)param.Icon] = rawData.GetValue(start_row, 13).ToString();
                        //}
                        //else if (rawData.GetValue(start_row, 7).ToString() != "")
                        //{
                        //    paramData[(int)param.Widget] = "CONTAINER";
                        //}
                        //if (rawData.GetValue(start_row, 12).ToString() != "")//h_align
                        //{
                        //    paramData[(int)param.AlignmentY] = "middle";
                        //}

                        if ((rawData.GetValue(start_row, 11).ToString() != "Font_Color") || (rawData.GetValue(start_row, 11).ToString() != null))//Font
                        {
                            for(int row1=0; row1<getRGB.GetLength(0); row1++)
                            {
                                if(rawData.GetValue(start_row, 11).ToString() == getRGB[row1,0]) //font color
                                {
                                    string data1 = null;
                                    for (int col=1; col<getRGB.GetLength(1); col++)
                                    {
                                        data1 += getRGB[row1, col];
                                        data1.ToArray();
                                        paramData[(int)param.ColorRGB] = data1;
                                     }
                                    //seperate the param data with whitespace
                                    paramData[(int)param.ColorRGB] = paramData[(int)param.ColorRGB].Insert(3, " ");//x_array
                                    paramData[(int)param.ColorRGB] = paramData[(int)param.ColorRGB].Insert(7, " ");
                                }
                            }
                        }

                        //if (rawData.GetValue(start_row, 13).ToString() != "")
                        //{
                        //    paramData[(int)param.FontSize] = rawData.GetValue(start_row, 13).ToString();
                        //    paramData[(int)param.FontSize] = paramData[(int)param.FontSize].Replace("px", "");
                        //}
                        //if (rawData.GetValue(start_row, 16).ToString() != "") // font
                        //{
                        //    paramData[(int)param.Font] = rawData.GetValue(start_row, 16).ToString();
                        //    paramData[(int)param.Font] = paramData[(int)param.Font].Replace(",", " ");

                        //int NrFontID = FontID_Trim_HY.Count();

                        //for (int cnt = 0; cnt < NrFontID;)
                        //{
                        //    if (paramData[(int)param.Font].Contains(FontID_Trim_HY[0]) || paramData[(int)param.Font].Contains(FontID_Trim_HY[1]))
                        //    {
                        //        paramData[(int)param.Font] = "TFontMono_" + paramData[(int)param.FontSize] + "xN";
                        //        //cnt++;
                        //    }
                        //    if (paramData[(int)param.Font].Contains(FontID_Trim_HY[2]))
                        //    {
                        //        paramData[(int)param.Font] = "TFontBold_" + paramData[(int)param.FontSize] + "xN";
                        //    }
                        //    else if (paramData[(int)param.Font].Contains(FontID_Trim_HY[3]))
                        //    {
                        //        paramData[(int)param.Font] = "TFontNonJP_" + paramData[(int)param.FontSize] + "xN";
                        //    }
                        //    break;  // force break when all scanned
                        //}
                        // }
                        GMTSparam.Add(new GMTS_Data
                        {
                            //Desc = rawData.GetValue(start_row, 1).ToString(),
                            //X_px = rawData.GetValue(start_row, 6).ToString() + ,call param data directly
                            //Y_px = rawData.GetValue(start_row, 7).ToString(),
                            //Width = rawData.GetValue(start_row, 8).ToString(),
                            //Height = rawData.GetValue(start_row, 9).ToString(),
                            //Font = paramData[(int)param.Font],
                            //Font_size = paramData[(int)param.FontSize],
                            //Color_RGB = paramData[(int)param.ColorRGB],
                            //Alignment_X = rawData.GetValue(start_row, 12).ToString(),//h_align
                            //Alignment_Y = "center",//v_align
                            //Resource = paramData[(int)param.Icon],
                            //Widget = paramData[(int)param.Widget],
                            //Visibility = "TRUE",
                            //API = paramData[(int)param.API],
                            //Data_Type = paramData[(int)param.DataType],
                            //Default_Value = "",
                            //PConditions = "",
                            //Scale = "",
                            //PValues = ""
                            Desc = "",
                            X_px = "",
                            Y_px = "",
                            Width = "",
                            Height = "",
                            Font = "",
                            Font_size = "",
                            Color_RGB = paramData[(int)param.ColorRGB],
                            Alignment_X = "",//h_align
                            Alignment_Y = "",//v_align
                            Resource = "",
                            RESOURCE_ID = "",
                            Widget = "",
                            Visibility = "TRUE",
                            API = "",
                            Data_Type = "",
                            Default_Value = "",
                            PConditions = "",
                            Scale = "",
                            PValues = ""
                        });
                        reset_param_data();
                    }
                    while (start_row++ < xDepth);
                    GMTData.Add(GMTSparam);
                   start_row = 3;
                    PsdViewerList.Add(myWorkSheet.Name);
                }
        }
        workBookNameList.Add(myWorkBook.Name);
            Close_Excel();

        }
        //Hyundai ends here


        //Toyota strats here
        public void Get_Excel_Data(string[] path)
        {
            int sLength, sDepth, lenCtr = 1, row = 8;//toy styleguide change as per cfg file or project related
            
            workBookIdx = path.Count();
            List<string> data = new List<string>();

            myWorkBook = myAppl.Workbooks.Open(path[--workBookIdx]);
            PsdViewerList.Add(myWorkBook.Name);

            for (int i = 1; i <= myWorkBook.Worksheets.Count; i++)
            {
                myWorkSheet = (Excel.Worksheet)myWorkBook.Sheets[i];
                if (myWorkSheet.Name.ToLower() != "overview" && myWorkSheet.Name.ToLower() != "database")//omit the sheet dont want to read change
                {
                    //myWorkSheet.UsedRange.Worksheet.Cells.Value;
                    //System.Array myData = (System.Array)myWorkSheet.Range["A1","S30"].Cells.Value;
                    myData = (System.Array)myWorkSheet.UsedRange.Cells.Value;
                    sLength = myData.GetLength(1);  // column
                    sDepth = myData.GetLength(0);   // row
                    // Do some process to handle the data

                    for (int j = row; j <= sDepth; j++)
                    {
                        do
                        {
                            if (myData.GetValue(j, lenCtr) == null)
                            {
                                myData.SetValue("", j, lenCtr);
                            }
                            lenCtr++;
                        }
                        while (lenCtr <= sLength);
                        lenCtr = 2;//set counter to 2 after while loop
                    }

                    List<GMTS_Data> GMTSparam = new List<GMTS_Data>();
                    
                    do
                    {
                        if (myData.GetValue(row, 16).ToString() != "") // font col process in font apply  font //modify all there
                        {
                            paramData[(int)param.Widget]= "BASIC_TEXT";
                            paramData[(int)param.API] = myWorkSheet.Name + "_" + myData.GetValue(row, 3).ToString();//raw data
                            paramData[(int)param.DataType] = "DATA_TYPE_STRING";
                            paramData[(int)param.Icon] = "";
                           
                        }
                        else if (myData.GetValue(row, 3).ToString() != "")
                        {
                            paramData[(int)param.Widget] = "ICON";
                            paramData[(int)param.Icon] = myData.GetValue(row, 3).ToString();
                        }
                        else if (myData.GetValue(row, 7).ToString() != "")
                        {
                            paramData[(int)param.Widget] = "CONTAINER";
                        }
                        if (myData.GetValue(row, 11).ToString() != "")
                        {
                            paramData[(int)param.AlignmentY] = "onbaseline";
                        }
                        if (myData.GetValue(row, 14).ToString() != "")
                        {
                            paramData[(int)param.ColorRGB] = myData.GetValue(row, 14).ToString();
                            paramData[(int)param.ColorRGB] = Regex.Replace(paramData[(int)param.ColorRGB], "[^0-9.,]", "");
                            paramData[(int)param.ColorRGB] = paramData[(int)param.ColorRGB].Replace(",", " ");
                        }
                        if (myData.GetValue(row, 13).ToString() != "")
                        {
                            paramData[(int)param.FontSize] = myData.GetValue(row, 13).ToString();
                            paramData[(int)param.FontSize] = paramData[(int)param.FontSize].Replace("px","");
                        }
                        if (myData.GetValue(row, 16).ToString() != "") // font
                        {
                            paramData[(int)param.Font] = myData.GetValue(row, 16).ToString();
                            paramData[(int)param.Font] = paramData[(int)param.Font].Replace(","," ");

                            int NrFontID = FontID_Trim.Count();

                            for(int cnt=0; cnt< NrFontID;)
                            {
                                if (paramData[(int)param.Font].Contains(FontID_Trim[0]) || paramData[(int)param.Font].Contains(FontID_Trim[1]))
                                {
                                    paramData[(int)param.Font] = "TFontMono_" + paramData[(int)param.FontSize] + "xN";
                                   //cnt++;
                                }
                                if (paramData[(int)param.Font].Contains(FontID_Trim[2]))
                                {
                                    paramData[(int)param.Font] = "TFontBold_" + paramData[(int)param.FontSize] + "xN";
                                }
                                else if (paramData[(int)param.Font].Contains(FontID_Trim[3]))
                                {
                                    paramData[(int)param.Font] = "TFontNonJP_" + paramData[(int)param.FontSize] + "xN";
                                }
                                break;  // force break when all scanned
                            }
                        }
                        GMTSparam.Add(new GMTS_Data
                        {
                            Desc = myData.GetValue(row, 3).ToString(),
                            X_px = myData.GetValue(row, 7).ToString(),
                            Y_px = myData.GetValue(row, 8).ToString(),
                            Width = myData.GetValue(row, 9).ToString(),
                            Height = myData.GetValue(row, 10).ToString(),
                            Font = paramData[(int)param.Font],
                            Scale = myData.GetValue(row, 6).ToString(),
                            Font_size = paramData[(int)param.FontSize],
                            Color_RGB = paramData[(int)param.ColorRGB],
                            Alignment_X = myData.GetValue(row, 11).ToString(),
                            Alignment_Y = paramData[(int)param.AlignmentY],
                            Resource = paramData[(int)param.Icon],
                            RESOURCE_ID = paramData[(int)param.Icon].ToUpper(),
                            Widget = paramData[(int)param.Widget],
                            Visibility = "TRUE",
                            API = paramData[(int)param.API],
                            Data_Type = paramData[(int)param.DataType],
                            Default_Value = myData.GetValue(row,2).ToString(),
                            PConditions = "",
                            PValues = ""
                        });
                        reset_param_data();
                    }
                    while (row++ < sDepth);
                    GMTData.Add(GMTSparam);
                    row = 8;
                    PsdViewerList.Add(myWorkSheet.Name);
                }
            }
            workBookNameList.Add(myWorkBook.Name);
            Close_Excel();

            //Data_Manager();
        }
        //Toyota ends here
        private void reset_param_data()
        {
            paramData[(int)param.Widget] = "";
            paramData[(int)param.DataType] = "";
            paramData[(int)param.API] = "";
            paramData[(int)param.AlignmentY] = "";
            paramData[(int)param.FontSize] = "";
            paramData[(int)param.Font] = "";
            paramData[(int)param.Icon] = "";
            paramData[(int)param.ColorRGB] = "";
        }
        
        private void Data_Manager()//change here also
        {
            int page = 0, row = 0;

            for(page=0; page<GMTData.Count; page++)
            {
                for(row=0; row< GMTData[page].Count; row++)
                {
                    // read complete data from array
                    //Regex.Replace(GMTData[page][row].Color_RGB, "[^0-9.]", "");
                    //Regex.Replace(GMTData[page][row].Font_size, "[^0-9.]", "");
                    if(myData.GetValue(row, 14).ToString() != "")
                    {
                        //myData.SetValue()
                    }


                    if (GMTData[page][row].Font != "")
                    {
                        //Regex.Replace(GMTData[page][row].Widget,"","BASIC_TEXT");
                        //Regex.Replace(GMTData[page][row].API,"", PsdViewerList.ElementAt(page + 1) + "_" + GMTData[page][row].Desc);
                    }
                    if (GMTData[page][row].Resource != "")
                    {
                        //Regex.Replace(GMTData[page][row].Widget,"","ICON");
                    }
                    if (GMTData[page][row].Desc != "" && GMTData[page][row].X_px == "")
                    {
                        //Regex.Replace(GMTData[page][row].Widget,"", "CONTAINER");
                    }
                }

            }


            
        }


    }
    public class GMTS_Data
    {
        public string Desc { get; set; }
        public string X_px { get; set; }
        public string Y_px { get; set; }
        public string Width { get; set; }
        public string Height { get; set; }
        public string Font { get; set; }
        public string Scale { get; set; }
        public string Font_size { get; set; }
        public string Color_RGB { get; set; }
        public string Alignment_X { get; set; }
        public string Alignment_Y { get; set; }
        public string Resource { get; set; }
        public string RESOURCE_ID { get; set; }
        public string Widget { get; set; }
        public string Visibility { get; set; }
        public string API { get; set; }
        public string Data_Type { get; set; }
        public string Default_Value { get; set; }
        public string PConditions { get; set; }
        public string PValues { get; set; }
    }
    
}
