﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;

namespace Automatic_Modeling.CLASSES
{
    class ExcelConnection
    {
        private OleDbConnection ExcelConnect;
        private OleDbCommand ExcelCommand;

        public ExcelConnection(string connectionstring)
        {
            ExcelConnect = new OleDbConnection(connectionstring);
            //ExcelConnect.Open();
        }
        #region QUERIES
        public void ExecuteNonQuery(string SQL)
        {
            ExcelConnect.Open();
            ExcelCommand = ExcelConnect.CreateCommand();
            ExcelCommand.CommandText = SQL;
            ExcelCommand.ExecuteNonQuery();
            ExcelCommand.Dispose();
            ExcelConnect.Close();
        }

        public DataTable ExecuteQueryDatatable(string SQL)
        {
            DataTable dt = new DataTable();
            
            ExcelConnect.Open();
            ExcelCommand = new OleDbCommand(SQL, ExcelConnect);
            using (OleDbDataReader ExcelReader = ExcelCommand.ExecuteReader())
            {
                dt.Load(ExcelReader);
                
            }
            ExcelCommand.Dispose();
            //ExcelConnect.Dispose();
            ExcelConnect.Close();

            return dt;
        }        

        public String ExecuteQueryScalar(string SQL)
        {
            String str = "";
            ExcelConnect.Open();
            ExcelCommand = ExcelConnect.CreateCommand();
            try
            {
                ExcelCommand.CommandText = SQL;
                Object SQLScalar = ExcelCommand.ExecuteScalar();
                if (SQLScalar != null)
                    str = SQLScalar.ToString();
            }
            catch (Exception err)
            {
                //MessageBox.Show("Excel sheet name error, Please remove blank spaces or special character \n\r" + err + "");
                str = "";
            }
            ExcelCommand.Dispose();
            ExcelConnect.Close();

            return str;
        }

        public String[] ExecuteQuerySheets()
        {             
            DataTable dt_sheets = new DataTable();
            ExcelConnect.Open();
            dt_sheets = ExcelConnect.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            String[] sheets = new String[dt_sheets.Rows.Count];
            for (int i = 0; i < dt_sheets.Rows.Count; i++)
            {
                sheets[i] = dt_sheets.Rows[i]["Table_Name"].ToString();
                // Remove quotes (') when extract the table names, fixed error.
                sheets[i] = sheets[i].Replace("'","");
            }            
            ExcelConnect.Close();
            return sheets;
        }

        public void Close()
        {
            ExcelConnect.Close();
        }
        #endregion
    }
}
