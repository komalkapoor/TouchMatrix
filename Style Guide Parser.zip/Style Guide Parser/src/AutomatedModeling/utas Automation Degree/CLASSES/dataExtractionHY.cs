﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using ExcelConnect.CLASSES;

namespace ExcelConnect.CLASSES
{
    //public class dataExtractionHY
    //{
    //    ExcelHandler excel = new ExcelHandler();
        
    //    public dataExtractionHY()
    //    {
    //        extractDataRGB();
    //    }
        

    //    public void extractDataRGB()
    //    {

    //        int c4, c5, c6, c7;
    //        string[] a_1Column = null;
    //        string[] c_1Column = null;
    //        string[] d_1Column = null;
    //        string[] e_1Column = null;
    //        List<string> a_1lstColumn = new List<string>();
    //        List<string> c_1lstColumn = new List<string>();
    //        List<string> d_1lstColumn = new List<string>();
    //        List<string> e_1lstColumn = new List<string>();

    //        Excel.Workbook xlBook;
    //        Excel.Worksheet xlSheet;
    //        Excel.Application myAppl;

    //        xlBook = excel.getxcelbook();
    //        xlSheet = excel.getxcelsheet();
    //        myAppl = excel.getxcelapp();

    //        xlSheet = xlBook.ActiveSheet;
               
    //            //locate sheet name "font_color_layout"
    //            if (xlSheet.Name.ToLower() == "font_color_layout")
    //            {
    //            // get used range of column A
    //            Microsoft.Office.Interop.Excel.Range range_2 = xlSheet.UsedRange.Columns["A", Type.Missing];
    //                //read only int data type in row
    //                //string checkFormat = range_2.EntireRow.NumberFormat.ToString();


    //                // get number of used rows in column A
    //                int rngCount_2 = range_2.Rows.Count;

    //                //for col A
    //                for (c4 = 1; c4 <= rngCount_2; c4++)
    //                {
    //                    if (c4 >= 3 && c4 <= 27)
    //                    {
    //                        a_1lstColumn.Add(xlSheet.Cells[c4, "A"].Value.ToString());
    //                        a_1Column = a_1lstColumn.ToArray();//get all the font_color names
    //                    }
    //                }

    //                //for col C
    //                for (c5 = 1; c5 <= rngCount_2; c5++)
    //                {
    //                    c_1lstColumn.Add(xlSheet.Cells[c5, "C"].Value.ToString());
    //                    c_1Column = c_1lstColumn.ToArray();//get all the C values
    //                }
    //                //for col D
    //                for (c6 = 1; c6 <= rngCount_2; c6++)
    //                {
    //                    d_1lstColumn.Add(xlSheet.Cells[c6, "D"].Value.ToString());
    //                    d_1Column = d_1lstColumn.ToArray();//get all the D values                       
    //                }
    //                //for col E
    //                for (c7 = 1; c7 <= rngCount_2; c7++)
    //                {
    //                    e_1lstColumn.Add(xlSheet.Cells[c4, "E"].Value.ToString());
    //                    e_1Column = e_1lstColumn.ToArray();//get all the E values                       
    //                }
                   

    //                xlBook.Close();
    //                myAppl.Quit();

    //                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlSheet);
    //                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlBook);
    //                System.Runtime.InteropServices.Marshal.ReleaseComObject(myAppl);
    //            }
    //        }
    //    }
    }

